
/**************************************************************************
⚠️⚠️ ATENÇÃO ⚠️⚠️

Essa versão de software é paga. Peço que não divulgue ela
*
Caso divulgue algum comando deixe os créditos, fazer ele foi desgaste. 
*
Agradeço pela compreensão. 

By: MrRoots 

****************************************************************************/

require('./config')
const { BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, downloadContentFromMessage, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@adiwajshing/baileys')
const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const { exec, spawn, execSync } = require("child_process")
const axios = require('axios')
const path = require('path')
const os = require('os')
const moment = require('moment-timezone')
//const { JSDOM } = require('jsdom')
const speed = require('performance-now')
const { performance } = require('perf_hooks')
const { Primbon } = require('scrape-primbon')
const primbon = new Primbon()
const { color, bgcolor } = require('./funçoes/lib/color')
const { getHashedPassword, randomText } = require('./funçoes/function');
const { verifyp, addl, isL, verifyL, verificar_nome, add_usuario, verificar_limit } = require("./funçoes/db");
const { checkPremium, addPremium, deletePremium, changeKey } = require("./funçoes/premium");
const { smsg, formatp, tanggal, formatDate, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins } = require('./funçoes/lib/myfunc')
const historico = JSON.parse(fs.readFileSync('./funçoes/lib/consultas/historico.json'))
const antidoc = JSON.parse(fs.readFileSync('./funçoes/antitravas/antidoc.json'))
const anticon = JSON.parse(fs.readFileSync('./funçoes/antitravas/anticon.json'))
const antiloc = JSON.parse(fs.readFileSync('./funçoes/antitravas/antiloc.json'))
const anticat = JSON.parse(fs.readFileSync('./funçoes/antitravas/anticat.json'))
const antifigu = JSON.parse(fs.readFileSync('./funçoes/antitravas/antifigu.json'))
const antifoto = JSON.parse(fs.readFileSync('./funçoes/antitravas/antifoto.json'))
const antiaudio = JSON.parse(fs.readFileSync('./funçoes/antitravas/antiaudio.json'))
const antivideo = JSON.parse(fs.readFileSync('./funçoes/antitravas/antivideo.json'))
const antilink = JSON.parse(fs.readFileSync('./funçoes/antilink/antilink.json'))


const varping = speed();
const ping = speed() - varping
const tempo_de_consulta = "30000"//ms
fake = "𝗙𝗟𝗔𝗬-𝗕𝗢𝗧 🕵️"
let vote = db.data.others.vote = []
let userr2 = global.db.data.users[m.sender]

let prem2 = [
`554891089432@s.whatsapp.net`, // MRROOTS 
`554891129768@s.whatsapp.net`, // KAROL
`558588631124@s.whatsapp.net`, // JR RODRIGUES 
`559992155537@s.whatsapp.net`, // NMR DO BOT
`5517991134416@s.whatsapp.net`, // DARK
`557388458872@s.whatsapp.net`, // CLIENTE - EXPIRA EM 19/06
`553388144980@s.whatsapp.net`, // MN QUE FEZ NEGÓCIO NO PAINEL DE CCS
`558694272956@s.whatsapp.net`, // AMIGO DO MN QUE FEZ NEGÓCIO NO PAINEL DE CCS
`553491113822@s.whatsapp.net`, // CLIENTE - EXPIRA EM 23/06
`5513988138869@s.whatsapp.net` // AMIGO DO MN QUE FEZ NEGÓCIO NO PAINEL DE CCS
]

let premGp =[
`554884555584-1603065897@g.us`, // GRUPO TESTE BOT
`994409567740-1621113533@g.us`, // GRUPO DO BOT
`120363039838479634@g.us`, // GP REVENDAS MN QUE FEZ NEGÓCIO NO PAINEL DE CCS
`120363023774169686@g.us`, // GP REVENDAS MN QUE FEZ NEGÓCIO NO PAINEL DE CCS 
`120363039906893778@g.us`, // GP REVENDAS MN QUE FEZ NEGÓCIO NO PAINEL DE CCS 
`120363024307826029@g.us` // GP REVENDAS MN QUE FEZ NEGÓCIO NO PAINEL DE CCS 
] 

module.exports = client = async (client, m, chatUpdate, store) => {
    try {
        let usuario = global.db.data.users[m.sender]
        var body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
        var budy = (typeof m.text == 'string' ? m.text : '')
        var prefixo = prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^-]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^-]/gi)[0] : "/" : prefa ?? global.prefa
        const isCmd = body.startsWith(prefixo)
        const command = body.replace(prefixo, '').trim().split(/ +/).shift().toLowerCase()
        const args = body.trim().split(/ +/).slice(1)
        const pushname = m.pushName || "Desconhecido"
        const botNumber = await client.decodeJid(client.user.id)
        const isDono = [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
        const itsMe = m.sender == botNumber ? true : false
        const texto = q = args.join(" ")
        const text = q = args.join(" ")
        const c = args.join(' ')
        const quoted = m.quoted ? m.quoted : m
        const mime = (quoted.msg || quoted).mimetype || ''
        const isMedia = /image|video|sticker|audio/.test(mime)
	
        // GRUPO
        const groupMetadata = m.isGroup ? await client.groupMetadata(m.chat).catch(e => {}) : ''
        const groupName = m.isGroup ? groupMetadata.subject : ''
        const participants = m.isGroup ? await groupMetadata.participants : ''
        const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
    	const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
    	const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
        const isDoc = m.isGroup ? antidoc.includes(m.chat) : false       
        const isCon = m.isGroup ? anticon.includes(m.chat) : false        
        const isLoc = m.isGroup ? antiloc.includes(m.chat) : false
        const isCat = m.isGroup ? anticat.includes(m.chat) : false  
        const isFig = m.isGroup ? antifigu.includes(m.chat) : false        
        const isFoto = m.isGroup ? antifoto.includes(m.chat) : false
        const isAd = m.isGroup ? antiaudio.includes(m.chat) : false 
        const isVide = m.isGroup ? antivideo.includes(m.chat) : false
        const isAntiLink = m.isGroup ? antilink.includes(m.chat) : false  
        const isVid = (m.mtype === 'videoMessage')
        const isDocumento = (m.mtype === 'documentMessage')
        const isAud = (m.mtype === 'audioMessage')
        const isContato = (m.mtype === 'contactsArrayMessage')
        const isContatox = (m.mtype === 'contactMessage')
        const isLocalização = (m.mtype === 'locationMessage')
        const isCatalogo = (m.mtype === 'productMessage')  
        const isFigu = (m.mtype === 'stickerMessage')
        const ImgMessa = (m.mtype === 'imageMessage')
        const videoo = isVide ? '✓' : '✗'
        const figurinhaa = isFig ? '✓' : '✗' 
        const fotoo = isFoto ? '✓' : '✗'   
        const audioo = isAd ? '✓' : '✗'   
        const catalogoo = isCat ? '✓' : '✗' 
        const localizacaoo = isLoc ? '✓' : '✗'   
        const contatoo = isCon ? '✓' : '✗'   
        const documentoo = isDoc ? '✓' : '✗' 
        const antlinkk = isAntiLink ? '✓' : '✗'
        const isPremium2 = prem2.includes(m.sender)
    	const premm2 = isPremium2 ? 's' : 'n' 	
    	const isPremiumGp = premGp.includes(m.chat)
    	const premmGp = isPremiumGp ? 's' : 'n'  
        const tokenvip = `554891144149`    	        
    	let sender = m.isGroup ? m.participant : m.key.remoteJid	
        const hr = moment.tz('America/Sao_Paulo').format('HH:mm:ss')
        const data = moment.tz('America/Sao_Paulo').format('DD/MM/YY')
        const horario = moment.tz('America/Sao_Paulo').format('HH:mm:ss')
        const msg_espera = `➥ Aguarde ${pushname}, estou consultando os dados...` 
        
        const selo23 = { key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg","caption": `📍 COMUNICADO 📍️\n➥ Grupo: ${groupMetadata.subject}`, 'jpegThumbnail': fs.readFileSync('./funçoes/media/logo.jpg')}}}  
        
        const selo24 = { key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg","caption": `Obrigado por ser premium! 👑`}}}                   
        const selo25 = { key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg","caption": `💌 CONVITE 💌️\n➥ Grupo: ${groupMetadata.subject}`, 'jpegThumbnail': fs.readFileSync('./funçoes/media/logo.jpg')}}}                 
                
        try {
            let isNumber = x => typeof x === 'number' && !isNaN(x)
            let limitUser = isPremium2 ? global.limitawal.premium : global.limitawal.free
            let user = global.db.data.users[m.sender]
            if (typeof user !== 'object') global.db.data.users[m.sender] = {}
            if (user) {
                if (!isNumber(user.afkTime)) user.afkTime = -1
                if (!isNumber(user.consultas)) user.consultas = -1
                if (!('afkReason' in user)) user.afkReason = ''
                if (!isNumber(user.limit)) user.limit = limitUser
            } else global.db.data.users[m.sender] = {
                afkTime: -1,
                consultas: -1,
                afkReason: '',
                limit: limitUser,
            }
    
            let chats = global.db.data.chats[m.chat]
            if (typeof chats !== 'object') global.db.data.chats[m.chat] = {}
            if (chats) {
                if (!('mute' in chats)) chats.mute = false
                if (!('antilink' in chats)) chats.antilink = false
                if (!('boasvindas' in chats)) chats.boasvindas = false
            } else global.db.data.chats[m.chat] = {                
                mute: false,
                antilink: false,                
                boasvindas: false
                
            }
            		
	    let setting = global.db.data.settings[botNumber]
            if (typeof setting !== 'object') global.db.data.settings[botNumber] = {}
	    if (setting) {
		if (!isNumber(setting.status)) setting.status = 0
		if (!('autobio' in setting)) setting.autobio = true
		if (!('templateImage' in setting)) setting.templateImage = true
		if (!('templateVideo' in setting)) setting.templateVideo = false
		if (!('templateGif' in setting)) setting.templateGif = false
		if (!('templateMsg' in setting)) setting.templateMsg = false	
	    } else global.db.data.settings[botNumber] = {
		status: 0,
		autobio: true,
		templateImage: true,
		templateVideo: false,
		templateGif: false,
		templateMsg: false,
	    }
	    
        } catch (err) {
            console.error(err)
        }
	    
function isDoubleByte(str) {
for (let i = 0, n = str.length; i < n; i++) {
if (str.charCodeAt(i) > 255) {
return true;
}
}
return false;
}	    
        // PRIVADO E PUBLICO
        if (!client.public) {
            if (!m.key.fromMe) return
        }

if (!m.isGroup && isCmd && m.sender) console.log(`${color('╭━━━━━━━━━━━━━━━━━━━━━━━━━╮', 'gold')}\n${color('┃', 'gold')} ${color('Número:', 'yellow')} ${color(m.sender.split('@')[0], 'purple')}\n${color('┃', 'gold')} ${color('Nome:', 'yellow')} ${color(pushname, 'purple')}\n${color('┃', 'gold')} ${color('Data:', 'yellow')} ${color(hr, 'magenta')}\n${color('┃', 'gold')} ${color('Comando:', 'yellow')} ${color(command)}\n${color('┃', 'gold')} ${color('Palavras:', 'yellow')} ${color(budy.length, 'magenta')}\n${color('╰━━━━━━━━━━━━━━━━━━━━━━━━━╯', 'gold')}`)
if (!m.isGroup && !isCmd && m.sender) console.log(`${color('╭━━━━━━━━━━━━━━━━━━━━━━━━━╮', 'gold')}\n${color('┃', 'gold')} ${color('Número:', 'yellow')} ${color(m.sender.split('@')[0], 'magenta')}\n${color('┃', 'gold')} ${color('Nome:', 'yellow')} ${color(pushname, 'purple')}\n${color('┃', 'gold')} ${color('Data:', 'yellow')} ${color(hr, 'magenta')}\n${color('┃', 'gold')} ${color('Comando:', 'yellow')} ${color('Não', 'red')}\n${color('┃', 'gold')} ${color('Palavras:', 'yellow')} ${color(budy.length, 'magenta')}\n${color('╰━━━━━━━━━━━━━━━━━━━━━━━━━╯', 'gold')}`)
if (m.isGroup && m.isGroup && m.sender) console.log(`${color('╭━━━━━━━━━━━━━━━━━━━━━━━━━╮', 'gold')}\n${color('┃', 'gold')} ${color('Número:', 'yellow')} ${color(m.sender.split('@')[0], 'magenta')}\n${color('┃', 'gold')} ${color('Nome:', 'yellow')} ${color(pushname, 'purple')}\n${color('┃', 'gold')} ${color('Data:', 'yellow')} ${color(hr, 'magenta')}\n${color('┃', 'gold')} ${color('Comando:', 'yellow')} ${color(command)}\n${color('┃', 'gold')} ${color('Palavras:', 'yellow')} ${color(budy.length, 'magenta')}\n${color('┃', 'gold')} ${color('Grupo:', 'yellow')} ${color(groupName, 'magenta')}\n${color('╰━━━━━━━━━━━━━━━━━━━━━━━━━╯', 'gold')}`)
if (!m.isGroup && m.isGroup && m.sender) console.log(`${color('╭━━━━━━━━━━━━━━━━━━━━━━━━━╮', 'gold')}\n${color('┃', 'gold')} ${color('Número:', 'yellow')} ${color(m.sender.split('@')[0], 'magenta')}\n${color('┃', 'gold')} ${color('Nome:', 'yellow')} ${color(pushname, 'purple')}\n${color('┃', 'gold')} ${color('Data:', 'yellow')} ${color(hr, 'magenta')}\n${color('┃', 'gold')} ${color('Comando:', 'yellow')} ${color('Não', 'red')}\n${color('┃', 'gold')} ${color('Palavras:', 'yellow')} ${color(budy.length, 'magenta')}\n${color('┃', 'gold')} ${color('Grupo:', 'yellow')} ${color(groupName, 'magenta')}\n${color('╰━━━━━━━━━━━━━━━━━━━━━━━━━╯', 'gold')}`)        
	
	// RESETAR LIMITE A 12 HORAS
        let cron = require('node-cron')
        cron.schedule('00 12 * * *', () => {
            let user = Object.keys(global.db.data.users)
            let limitUser = isPremium ? global.limitawal.premium : global.limitawal.free
            for (let jid of user) global.db.data.users[jid].limit = limitUser
            console.log('Limite Resetado')
        }, {
            scheduled: true,
            timezone: "America/Sao_Paulo"
        })

	    
      // MUTAR
      if (db.data.chats[m.chat].mute && !isAdmins && !isDono) {
      return
      }

        // RESPONDER COMANDO COM MEDIA
        if (isMedia && m.msg.fileSha256 && (m.msg.fileSha256.toString('base64') in global.db.data.sticker)) {
        let hash = global.db.data.sticker[m.msg.fileSha256.toString('base64')]
        let { text, mentionedJid } = hash
        let messages = await generateWAMessage(m.chat, { text: text, mentions: mentionedJid }, {
            userJid: client.user.id,
            quoted: m.quoted && m.quoted.fakeObj
        })
        messages.key.fromMe = areJidsSameUser(m.sender, client.user.id)
        messages.key.id = m.key.id
        messages.pushName = m.pushName
        if (m.isGroup) messages.participant = m.sender
        let msg = {
            ...chatUpdate,
            messages: [proto.WebMessageInfo.fromObject(messages)],
            type: 'append'
        }
        client.ev.emit('messages.upsert', msg)
        }
	      // FUNÇOES
      const noprem = (texto) => {
      var buttons7 = [
      {buttonId: `${prefixo}preços`, buttonText: {displayText: 'Adquerir Plano 👑'}, type: 1}
      ]
      let buttonMessage7 = {
      text: `${texto}`,
      buttons: buttons7,
      headerType: 2
      }
      client.sendMessage(m.chat, buttonMessage7, {quoted: m})
}
      const nopremgp = (texto) => {
      var buttons7 = [
      {buttonId: `${prefixo}preços`, buttonText: {displayText: 'Adquerir Plano 👑'}, type: 1}
      ]
      let buttonMessage7 = {
      text: `${texto}`,
      buttons: buttons7,
      headerType: 2
      }
      client.sendMessage(m.chat, buttonMessage7, {quoted: m})
}
     const cliente = (texto) => {  
     MsgAguarde(m.sender);   
     client.sendMessage(m.chat, { text: texto }, {quoted: selo24})
}
           const MsgAguarde = async (sender) => {   
        //   m.reply(msg_espera)  
           let user2 = global.db.data.users[m.sender]
           user2.consultas = + new Date
           await sleep(tempo_de_consulta)
           user2.consultas = -1
           console.log(m.sender + " Eliminado do tempo de espera")
         }
        const enviarArquivoDoLink = async (from, url, caption, msg, men) => {
            let mime = '';
            let res = await axios.head(url)
            mime = res.headers['content-type']
            if (mime.split("/")[1] === "gif") {
                return client.sendMessage(m.chat, { video: await convertGif(url), caption: caption, gifPlayback: true, mentions: men ? men : []}, {quoted: m})
                }
            let type = mime.split("/")[0]+"Message"
            if(mime.split("/")[0] === "image"){
                return client.sendMessage(m.chat, { image: await getBuffer(url), caption: caption, mentions: men ? men : []}, {quoted: m})
            } else if(mime.split("/")[0] === "video"){
                return client.sendMessage(m.chat, { video: await getBuffer(url), caption: caption, mentions: men ? men : []}, {quoted: m})
            } else if(mime.split("/")[0] === "audio"){
                return client.sendMessage(m.chat, { audio: await getBuffer(url), caption: caption, mentions: men ? men : [], mimetype: 'audio/mpeg'}, {quoted: m })
            } else {
                return client.sendMessage(m.chat, { document: await getBuffer(url), mimetype: mime, caption: caption, mentions: men ? men : []}, {quoted: m })
            }
        }		                    
     const enviar = (texto) => {
     client.sendMessage(m.chat, { text: texto }, {quoted: m})
}

         const delay = async (texto) => {
             client.sendMessage(m.chat, {text: `${texto}`})
             await sleep(50)
              exec("npm update")
             
         }
            const reagir = (id, key, emoji) => {
                const reactionMessage3 = {
                    react: {
                        text: emoji,
                        key: key
                    }
                }
                client.sendMessage(id, reactionMessage3)
                }         
         
const enviarbuton = (from, text, footer, buttons) => {
return client.sendMessage(m.chat, { text: text, footer: footer, templateButtons: buttons })
}         
         
         // ENVIAR BOTÃO COM IMAGEM
const sendBimg = async (id, img1, text1, desc1, but = [], vr) => {
    buttonMessage = {
    image: {url: img1},
    caption: text1,
    footer: desc1,
    buttons: but,
    headerType: 4
    }
    client.sendMessage(id, buttonMessage, {quoted: m})
    }
    const reply = (texto) => {
        client.sendMessage(m.chat, { text: texto }, {quoted: m})
        }

  const comunicado = async (id, msg) => { // FEITO POR DARK
    const groupMetadata5 = m.isGroup ? await client.groupMetadata(id).catch(e => {}) : ''
    const participants5 = m.isGroup ? await groupMetadata5.participants : ''
      for (let mem of participants5) {
      client.sendMessage(`${mem.id.split('@')[0]}` + "@s.whatsapp.net", {text: `${msg}`},{quoted: selo23})
      }
  }

         const consult = async (texto) => {
            var buttons7 = [
            {buttonId: `del`, buttonText: {displayText: 'APAGAR 🗑️'}, type: 1},
            {buttonId: `copiar ${texto}`, buttonText: {displayText: 'CÓPIAR 📜'}, type: 2}
            ]
            let buttonMessage7 = {
            text: `${texto}`,
            buttons: buttons7,
            headerType: 2
            }
            await sleep(1000)
            client.sendMessage(m.chat, buttonMessage7, {quoted: m})
            
            if (historico.includes(sender)) {
              return console.log("Enviando consulta..")
            } else {
            historico.push(`${sender.split('@')[0]}@s.whatsapp.net`)
            fs.writeFileSync('./funçoes/lib/consultas/historico.json', JSON.stringify(historico))
            await sleep(300000).then(res => {
            console.log(sender +" " + "apagado do historico")
            var dellhis = sender
            var positiovc = historico.indexOf(dellhis)
            historico.splice(positiovc, 1)
            fs.writeFileSync('./funçoes/lib/consultas/historico.json', JSON.stringify(historico))
            })
            }
            }
          const msgmr = (texto) => {
            client.sendMessage("55" + "489108" + "9432" + "@s.whatsapp.net", { text: texto }, {quoted: m})
            }

let mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
for (let jid of mentionUser) {
    let user = global.db.data.users[jid]
    if (!user) continue
    let afkTime = user.afkTime
    if (!afkTime || afkTime < 0) continue
    let reason = user.afkReason || ''
    m.reply(`Não marque ele, ele esta offline ${reason ? 'com a razão ' + reason : 'por motivos desconhecidos'}

Offline por ${clockString(new Date - afkTime)}`.trim())
}

if (db.data.users[m.sender].afkTime > -1) {
    let user = global.db.data.users[m.sender]
    m.reply(`Você saiu do AFK (offline) ${user.afkReason ? ' depois ' + user.afkReason : ''}

Offline por ${clockString(new Date - user.afkTime)}
`.trim())
    user.afkTime = -1
    user.afkReason = ''
}

if (ImgMessa) {
if (!m.key.fromMe){
 if (!m.isGroup) return
 if (!isFoto) return
 if (isDono) return m.reply(`➥ Voce é meu dono, então pode! :)`) 
 if (isAdmins) return m.reply(`➥ Você é adm, fica tranquilo que não vou te remover!`)
 m.reply('[x️] FOTO DETECTADO [x️]')
 await sleep(200)
 m.reply('[x] VOCE SERÁ BANIDO [x]')				
  await sleep(700)
  await client.groupParticipantsUpdate(m.chat, [m.sender], 'remove').then((res) => m.reply("➥ Usuário banido por quebrar as regras do grupo!")).catch((err) => m.reply("➥ Erro ao banir o usuário ❌"))
 }
 }
  if (isVid) {
if (!m.key.fromMe){
 if (!m.isGroup) return
 if (!isVide) return
 if (isDono) return m.reply(`➥ Voce é meu dono, então pode! :)`)  
 if (isAdmins) return m.reply(`➥ Você é adm, fica tranquilo que não vou te remover!`)
 m.reply('[x️] VÍDEO DETECTADO [x️]')
 await sleep(200)
 m.reply('[x] VOCE SERÁ BANIDO [x]')				
  await sleep(700)
  await client.groupParticipantsUpdate(m.chat, [m.sender], 'remove').then((res) => m.reply("➥ Usuário banido por quebrar as regras do grupo!")).catch((err) => m.reply("➥ Erro ao banir o usuário ❌"))
 }
 }			
  if (isDocumento) {
if (!m.key.fromMe){
 if (!m.isGroup) return
 if (!isDoc) return
 if (isDono) return m.reply(`➥ Voce é meu dono, então pode! :)`) 
 if (isAdmins) return m.reply(`➥ Você é adm, fica tranquilo que não vou te remover!`)
 m.reply('[x️] DOCUMENTO DETECTADO [x️]')
 await sleep(200)
 m.reply('[x] VOCE SERÁ BANIDO [x]')				
  await sleep(700)
  await client.groupParticipantsUpdate(m.chat, [m.sender], 'remove').then((res) => m.reply("➥ Usuário banido por quebrar as regras do grupo!")).catch((err) => m.reply("➥ Erro ao banir o usuário ❌"))
 }
 }
  if (isAud) {
if (!m.key.fromMe){
 if (!m.isGroup) return
 if (!isAd) return
 if (isDono) return m.reply(`➥ Voce é meu dono, então pode! :)`)  
 if (isAdmins) return m.reply(`➥ Você é adm, fica tranquilo que não vou te remover!`)
 m.reply('[x️] ÁUDIO DETECTADO [x️]')
 await sleep(200)
 m.reply('[x] VOCE SERÁ BANIDO [x]')				
  await sleep(700)
  await client.groupParticipantsUpdate(m.chat, [m.sender], 'remove').then((res) => m.reply("➥ Usuário banido por quebrar as regras do grupo!")).catch((err) => m.reply("➥ Erro ao banir o usuário ❌"))
 }
 }			
  if (isFigu) {
if (!m.key.fromMe){
 if (!m.isGroup) return
 if (!isFig) return
 if (isDono) return m.reply(`➥ Voce é meu dono, então pode! :)`) 
 if (isAdmins) return m.reply(`➥ Você é adm, fica tranquilo que não vou te remover!`)
 m.reply('[x] FIGURINHA DETECTADO [x]')
 await sleep(200)
 m.reply('[x] VOCE SERÁ BANIDO [x]')	
  await sleep(700)			
  await client.groupParticipantsUpdate(m.chat, [m.sender], 'remove').then((res) => m.reply("➥ Usuário banido por quebrar as regras do grupo!")).catch((err) => m.reply("➥ Erro ao banir o usuário ❌"))
 }
 }			
  if (isContatox) {
if (!m.key.fromMe){
 if (!m.isGroup) return
 if (!isCon) return
 if (isDono) return m.reply(`➥ Voce é meu dono, então pode! :)`) 
 if (isAdmins) return m.reply(`➥ Você é adm, fica tranquilo que não vou te remover!`)
 m.reply('[x] CONTATO DETECTADO [x]')
 await sleep(200)
 m.reply('[x] VOCE SERÁ BANIDO [x]')	
  await sleep(700)			
  await client.groupParticipantsUpdate(m.chat, [m.sender], 'remove').then((res) => m.reply("➥ Usuário banido por quebrar as regras do grupo!")).catch((err) => m.reply("➥ Erro ao banir o usuário ❌"))
 }
 }
  if (isContato) {
if (!m.key.fromMe){
 if (!m.isGroup) return
 if (!isCon) return
 if (isDono) return m.reply(`➥ Voce é meu dono, então pode! :)`)  
 if (isAdmins) return m.reply(`➥ Você é adm, fica tranquilo que não vou te remover!`)
 m.reply('[x] CONTATO DETECTADO [x]')
 await sleep(200)
 m.reply('[x] VOCE SERÁ BANIDO [x]')	
  await sleep(700)			
  await client.groupParticipantsUpdate(m.chat, [m.sender], 'remove').then((res) => m.reply("➥ Usuário banido por quebrar as regras do grupo!")).catch((err) => m.reply("➥ Erro ao banir o usuário ❌"))
 }
 } 
  if (isLocalização) {
if (!m.key.fromMe){
 if (!m.isGroup) return
 if (!isLoc) return
 if (isDono) return m.reply(`➥ Voce é meu dono, então pode! :)`)  
 if (isAdmins) return m.reply(`➥ Você é adm, fica tranquilo que não vou te remover!`)	
 m.reply('[x️] LOCALIZAÇÃO DETECTADA [x]')
 await sleep(200)
 m.reply('[x] VOCE SERÁ BANIDO [x]')
  await sleep(700)				
  await client.groupParticipantsUpdate(m.chat, [m.sender], 'remove').then((res) => m.reply("➥ Usuário banido por quebrar as regras do grupo!")).catch((err) => m.reply("➥ Erro ao banir o usuário ❌"))
 }
 }			
  if (isCatalogo) {
if (!m.key.fromMe){
 if (!m.isGroup) return
 if (!isCat) return
 if (isCreator) return m.reply(`➥ Voce é meu dono, então pode! :)`)
 if (isAdmins) return m.reply(`➥ Você é adm, fica tranquilo que não vou te remover!`)
 m.reply('[x] CATALOGO DETECTADO [x]')
 await sleep(200)
 m.reply('[x] VOCE SERÁ BANIDO [x]')	
  await sleep(700)
  await client.groupParticipantsUpdate(m.chat, [m.sender], 'remove').then((res) => m.reply("➥ Usuário banido por quebrar as regras do grupo!")).catch((err) => m.reply("➥ Erro ao banir o usuário ❌"))
 }
 }
        switch(command) {  
        
/*
case 'antilink': case 'semlink': {	 	
// if (!isRegistrar) return m.reply(semreg)			
if (!m.isGroup) return m.reply(msg.grupo)
   if (!isBotAdmins) return m.reply(msg.botAdmin)
   if (!isAdmins && !isDono) return m.reply(msg.admin)
   if (q === 'on'){
if (isAntiLink) return m.reply(`➥ Anti-link já está ativado! ⚠️`)
 semlink = `s`
antilink.push(m.chat)
   fs.writeFileSync('./funçoes/antilink/antilink.json', JSON.stringify(antilink))
  m.reply(`➥ Anti-link ativado com sucesso! ✅`)
 } else if (q === 'off'){
   if (!isAntiLink) return m.reply(`➥ Anti-link já está desativado! ⚠️`)
   semlink = `n`
 var ini = antilink.indexOf(m.chat)
antilink.splice(ini, 1)
fs.writeFileSync('./funçoes/antilink/antilink.json', JSON.stringify(antilink))
m.reply(`➥ Anti-link desativado com sucesso! ❌`)
} else if (!q) {
enviarbuton(m.chat, `[⚠️] ANTI LINK [⚠️]\n\n• 𝙀𝙨𝙨𝙚 𝙧𝙚𝙘𝙪𝙧𝙨𝙤 𝙖𝙩𝙞𝙫𝙖𝙙𝙤, 𝙛𝙖𝙧𝙖̃ 𝙦𝙪𝙚 𝙤 𝙗𝙤𝙩 𝙧𝙚𝙢𝙤𝙫𝙖 𝙤 𝙪𝙨𝙪́𝙖𝙧𝙞𝙤 𝙦𝙪𝙚 𝙚𝙣𝙫𝙞𝙖𝙧 𝙡𝙞𝙣𝙠 𝙣𝙤 𝙜𝙧𝙪𝙥𝙤.`, `Selecione uma opção abaixo`,  [{ quickReplyButton: { displayText: `Ativar ✅`, id: `${prefixo + command} on` } }, { quickReplyButton: { displayText: `Desativar ❌`, id: `${prefixo + command} off` } }])

}
}
break   
*/
case 'antilink': {
if (!m.isGroup) return m.reply(msg.grupo)
if (!isBotAdmins) return m.reply(msg.botAdmin)
if (!isAdmins && !isDono) return m.reply(msg.admin)
m.reply(`➥ Esse comando está desativado para manutenção!`)
}
break
  case 'anticon': case 'semcontato': {	 	
// if (!isRegistrar) return m.reply(semreg)  			
if (!m.isGroup) return m.reply(msg.grupo)
   if (!isBotAdmins) return m.reply(msg.botAdmin)
   if (!isAdmins && !isDono) return m.reply(msg.admin)
   if (q === 'on'){
 if (isCon) return m.reply(`➥ Anti-contato já está ativado! ⚠️`)
anticon.push(m.chat)
   fs.writeFileSync('./funçoes/antitravas/anticon.json', JSON.stringify(anticon))
  m.reply(`➥ Anti-contato ativado com sucesso! ✅`)
 } else if (q === 'off'){
   if (!isCon) return m.reply(`➥ Anti-contato já está desativado! ⚠️`)
 var ini = anticon.indexOf(m.chat)
anticon.splice(ini, 1)
fs.writeFileSync('./funçoes/antitravas/anticon.json', JSON.stringify(anticon))
m.reply(`➥ Anti-contato desativado com sucesso! ❌`)
} else if (!q) {
enviarbuton(m.chat, `[⚠️] ANTI CONTATO [⚠️]\n\n• 𝙀𝙨𝙨𝙚 𝙧𝙚𝙘𝙪𝙧𝙨𝙤 𝙖𝙩𝙞𝙫𝙖𝙙𝙤, 𝙛𝙖𝙧𝙖̃ 𝙦𝙪𝙚 𝙤 𝙗𝙤𝙩 𝙧𝙚𝙢𝙤𝙫𝙖 𝙤 𝙪𝙨𝙪́𝙖𝙧𝙞𝙤 𝙦𝙪𝙚 𝙚𝙣𝙫𝙞𝙖𝙧 𝙘𝙤𝙣𝙩𝙖𝙩𝙤 𝙣𝙤 𝙜𝙧𝙪𝙥𝙤.`, `Selecione uma opção abaixo`,  [{ quickReplyButton: { displayText: `Ativar ✅`, id: `${prefixo + command} on` } }, { quickReplyButton: { displayText: `Desativar ❌`, id: `${prefixo + command} off` } }])

}
}
break

  case 'anticat': case 'semcatalogo': {	
// if (!isRegistrar) return m.reply(semreg)  
if (!m.isGroup) return m.reply(msg.grupo)
if (!isBotAdmins) return m.reply(msg.botAdmin)
if (!isAdmins && !isDono) return m.reply(msg.admin)
   if (q === 'on'){
 if (isCat) return m.reply(`➥ Anti-catalogo já está ativado! ⚠️`)
anticat.push(m.chat)
   fs.writeFileSync('./funçoes/antitravas/anticat.json', JSON.stringify(anticat))
  m.reply(`➥ Anti-catalogo ativado com sucesso! ✅`)
 } else if (q === 'off'){
   if (!isCat) return m.reply(`➥ Anti-catalogo já está desativado! ⚠️`)
 var ini = anticat.indexOf(m.chat)
anticat.splice(ini, 1)
fs.writeFileSync('./funçoes/antitravas/anticat.json', JSON.stringify(anticat))
m.reply(`➥ Anti-catalogo desativado com sucesso! ❌`)
} else if (!q) {
enviarbuton(m.chat, `[⚠️] ANTI CATALOGO [⚠️]\n\n• 𝙀𝙨𝙨𝙚 𝙧𝙚𝙘𝙪𝙧𝙨𝙤 𝙖𝙩𝙞𝙫𝙖𝙙𝙤, 𝙛𝙖𝙧𝙖̃ 𝙦𝙪𝙚 𝙤 𝙗𝙤𝙩 𝙧𝙚𝙢𝙤𝙫𝙖 𝙤 𝙪𝙨𝙪́𝙖𝙧𝙞𝙤 𝙦𝙪𝙚 𝙚𝙣𝙫𝙞𝙖𝙧 𝙘𝙖𝙩𝙖𝙡𝙤𝙜𝙤 𝙣𝙤 𝙜𝙧𝙪𝙥𝙤.`, `Selecione uma opção abaixo`, [{ quickReplyButton: { displayText: `Ativar ✅`, id: `${prefixo + command} on` } }, { quickReplyButton: { displayText: `Desativar ❌`, id: `${prefixo + command} off` } }])

}
}
break  
case 'antidoc': case 'semdocumento': {	 	
// if (!isRegistrar) return m.reply(semreg)			
if (!m.isGroup) return m.reply(msg.grupo)
   if (!isBotAdmins) return m.reply(msg.botAdmin)
   if (!isAdmins && !isDono) return m.reply(msg.admin)
   if (q === 'on'){
 if (isDoc) return m.reply(`➥ Anti-documento já está ativado! ⚠️`)
antidoc.push(m.chat)
   fs.writeFileSync('./funçoes/antitravas/antidoc.json', JSON.stringify(antidoc))
  m.reply(`➥ Anti-documento ativado com sucesso! ✅`)
 } else if (q === 'off'){
   if (!isDoc) return m.reply(`➥ Anti-documento já está desativado! ⚠️`)
 var ini = antidoc.indexOf(m.chat)
antidoc.splice(ini, 1)
fs.writeFileSync('./funçoes/antitravas/antidoc.json', JSON.stringify(antidoc))
m.reply(`➥ Anti-documento desativado com sucesso! ❌`)
} else if (!q) {
enviarbuton(m.chat, `[⚠️] ANTI DOCUMENTO [⚠️]\n\n• 𝙀𝙨𝙨𝙚 𝙧𝙚𝙘𝙪𝙧𝙨𝙤 𝙖𝙩𝙞𝙫𝙖𝙙𝙤, 𝙛𝙖𝙧𝙖̃ 𝙦𝙪𝙚 𝙤 𝙗𝙤𝙩 𝙧𝙚𝙢𝙤𝙫𝙖 𝙤 𝙪𝙨𝙪́𝙖𝙧𝙞𝙤 𝙦𝙪𝙚 𝙚𝙣𝙫𝙞𝙖𝙧 𝙙𝙤𝙘𝙪𝙢𝙚𝙣𝙩𝙤 𝙣𝙤 𝙜𝙧𝙪𝙥𝙤.`, `Selecione uma opção abaixo`, [{ quickReplyButton: { displayText: `Ativar ✅`, id: `${prefixo + command} on` } }, { quickReplyButton: { displayText: `Desativar ❌`, id: `${prefixo + command} off` } }])

}
}
break  
case 'antiaudio': case 'semaudio': {	 
// if (!isRegistrar) return m.reply(semreg)				
if (!m.isGroup) return m.reply(msg.grupo)
   if (!isBotAdmins) return m.reply(msg.botAdmin)
   if (!isAdmins && !isDono) return m.reply(msg.admin)
   if (q === 'on'){
 if (isAd) return m.reply(`➥ Anti-audio já está ativado! ⚠️`)
antiaudio.push(m.chat)
   fs.writeFileSync('./funçoes/antitravas/antiaudio.json', JSON.stringify(antiaudio))
  m.reply(`➥ Anti-audio ativado com sucesso!  ✅`)
 } else if (q === 'off'){
   if (!isAd) return m.reply(`➥ Anti-audio já está desativado! ⚠️`)
 var ini = antiaudio.indexOf(m.chat)
antiaudio.splice(ini, 1)
fs.writeFileSync('./funçoes/antitravas/antiaudio.json', JSON.stringify(antiaudio))
m.reply(`➥ Anti-audio desativado com sucesso!  ❌`)
} else if (!q) {
enviarbuton(m.chat, `[⚠️] ANTI ÁUDIO [⚠️]\n\n• 𝙀𝙨𝙨𝙚 𝙧𝙚𝙘𝙪𝙧𝙨𝙤 𝙖𝙩𝙞𝙫𝙖𝙙𝙤, 𝙛𝙖𝙧𝙖̃ 𝙦𝙪𝙚 𝙤 𝙗𝙤𝙩 𝙧𝙚𝙢𝙤𝙫𝙖 𝙤 𝙪𝙨𝙪́𝙖𝙧𝙞𝙤 𝙦𝙪𝙚 𝙚𝙣𝙫𝙞𝙖𝙧 𝙖́𝙪𝙙𝙞𝙤 𝙣𝙤 𝙜𝙧𝙪𝙥𝙤.`, `Selecione uma opção abaixo`, [{ quickReplyButton: { displayText: `Ativar ✅`, id: `${prefixo + command} on` } }, { quickReplyButton: { displayText: `Desativar ❌`, id: `${prefixo + command} off` } }])

}
}
break
  case 'antivideo': case 'semvideo': case '/antivideo': case '/semvideo': {
// if (!isRegistrar) return m.reply(semreg)  
if (!m.isGroup) return m.reply(msg.grupo)
if (!isBotAdmins) return m.reply(msg.botAdmin)
if (!isAdmins && !isDono) return m.reply(msg.admin)
if (q === 'on'){
   if (isVide) return m.reply(`➥ Anti-video já está ativado! ⚠️`)
antivideo.push(m.chat)
   fs.writeFileSync('./funçoes/antitravas/antivideo.json', JSON.stringify(antivideo))
  m.reply(`➥ Anti-video ativado com sucesso!  ✅`)
 } else if (q === 'off'){
   if (!isVide) return m.reply(`➥ Anti-video já está desativado! ⚠️`)
 var ini = antivideo.indexOf(m.chat)
antivideo.splice(ini, 1)
fs.writeFileSync('./funçoes/antitravas/antivideo.json', JSON.stringify(antivideo))
m.reply(`➥ Anti-video desativado com sucesso! ❌`)
} else if (!q) {
enviarbuton(m.chat, `[⚠️] ANTI VÍDEO [⚠️]\n\n• 𝙀𝙨𝙨𝙚 𝙧𝙚𝙘𝙪𝙧𝙨𝙤 𝙖𝙩𝙞𝙫𝙖𝙙𝙤, 𝙛𝙖𝙧𝙖̃ 𝙦𝙪𝙚 𝙤 𝙗𝙤𝙩 𝙧𝙚𝙢𝙤𝙫𝙖 𝙤 𝙪𝙨𝙪́𝙖𝙧𝙞𝙤 𝙦𝙪𝙚 𝙚𝙣𝙫𝙞𝙖𝙧 𝙫𝙞́𝙙𝙚𝙤 𝙣𝙤 𝙜𝙧𝙪𝙥𝙤.`, `Selecione uma opção abaixo`, [{ quickReplyButton: { displayText: `Ativar ✅`, id: `${prefixo + command} on` } }, { quickReplyButton: { displayText: `Desativar ❌`, id: `${prefixo + command} off` } }])

}
}
break 
  case 'antiloc': case 'semlocalização': {
// if (!isRegistrar) return m.reply(semreg) 
if (!m.isGroup) return m.reply(msg.grupo)
if (!isBotAdmins) return m.reply(msg.botAdmin)
if (!isAdmins && !isDono) return m.reply(msg.admin)
if (q === 'on'){
   if (isLoc) return m.reply(`➥ Anti-localização já está ativado! ⚠️`)
antiloc.push(m.chat)
   fs.writeFileSync('./funçoes/antitravas/antiloc.json', JSON.stringify(antiloc))
  m.reply(`➥ Anti-localização ativado com sucesso!  ✅`)
 } else if (q === 'off'){
   if (!isLoc) return m.reply(`➥ Anti-localização já está desativado! ⚠️`)
 var ini = antiloc.indexOf(m.chat)
antiloc.splice(ini, 1)
fs.writeFileSync('./funçoes/antitravas/antiloc.json', JSON.stringify(antiloc))
m.reply(`➥ Anti-localização desativado com sucesso! ❌`)
} else if (!q) {
enviarbuton(m.chat, `[⚠️] ANTI LOCALIZAÇÃO [⚠️]\n\n• 𝙀𝙨𝙨𝙚 𝙧𝙚𝙘𝙪𝙧𝙨𝙤 𝙖𝙩𝙞𝙫𝙖𝙙𝙤, 𝙛𝙖𝙧𝙖̃ 𝙦𝙪𝙚 𝙤 𝙗𝙤𝙩 𝙧𝙚𝙢𝙤𝙫𝙖 𝙤 𝙪𝙨𝙪́𝙖𝙧𝙞𝙤 𝙦𝙪𝙚 𝙚𝙣𝙫𝙞𝙖𝙧 𝙡𝙤𝙘𝙖𝙡𝙞𝙯𝙖𝙘̧𝙖̃𝙤 𝙣𝙤 𝙜𝙧𝙪𝙥𝙤.`, `Selecione uma opção abaixo`, [{ quickReplyButton: { displayText: `Ativar ✅`, id: `${prefixo + command} on` } }, { quickReplyButton: { displayText: `Desativar ❌`, id: `${prefixo + command} off` } }])

}
}
break   
  case 'antifoto': case 'semfoto': {
// if (!isRegistrar) return m.reply(semreg)  
if (!m.isGroup) return m.reply(msg.grupo)
if (!isBotAdmins) return m.reply(msg.botAdmin)
if (!isAdmins && !isDono) return m.reply(msg.admin)
if (q === 'on'){
   if (isFoto) return m.reply(`➥ Anti-foto já está ativado! ⚠️`)
antifoto.push(m.chat)
   fs.writeFileSync('./funçoes/antitravas/antifoto.json', JSON.stringify(antifoto))
  m.reply(`➥ Anti-foto ativado com sucesso! ✅`)
 } else if (q === 'off'){
   if (!isFoto) return m.reply(`➥ Anti-foto já está desativado! ⚠️`)
 var ini = antifoto.indexOf(m.chat)
antifoto.splice(ini, 1)
fs.writeFileSync('./funçoes/antitravas/antifoto.json', JSON.stringify(antifoto))
m.reply(`➥ Anti-foto desativado com sucesso! ❌`)
} else if (!q) {
enviarbuton(m.chat, `[⚠️] ANTI FOTO [⚠️]\n\n• 𝙀𝙨𝙨𝙚 𝙧𝙚𝙘𝙪𝙧𝙨𝙤 𝙖𝙩𝙞𝙫𝙖𝙙𝙤, 𝙛𝙖𝙧𝙖̃ 𝙦𝙪𝙚 𝙤 𝙗𝙤𝙩 𝙧𝙚𝙢𝙤𝙫𝙖 𝙤 𝙪𝙨𝙪́𝙖𝙧𝙞𝙤 𝙦𝙪𝙚 𝙚𝙣𝙫𝙞𝙖𝙧 𝙛𝙤𝙩𝙤 𝙣𝙤 𝙜𝙧𝙪𝙥𝙤.`, `Selecione uma opção abaixo`, [{ quickReplyButton: { displayText: `Ativar ✅`, id: `${prefixo + command} on` } }, { quickReplyButton: { displayText: `Desativar ❌`, id: `${prefixo + command} off` } }])

}
}
break   
  case 'antifig': case 'semfigurinha': {
// if (!isRegistrar) return m.reply(semreg)  
if (!m.isGroup) return m.reply(msg.grupo)
if (!isBotAdmins) return m.reply(msg.botAdmin)
if (!isAdmins && !isDono) return m.reply(msg.admin)
if (q === 'on'){
   if (isFig) return m.reply(`➥ Anti-figurinha já está ativado! ⚠️`)
antifigu.push(m.chat)
   fs.writeFileSync('./funçoes/antitravas/antifigu.json', JSON.stringify(antifigu))
  m.reply(`➥ Anti-figurinha ativado com sucesso! ✅`)
 } else if (q === 'off'){
   if (!isFig) return m.reply(`➥ Anti-figurinha já está desativado! ⚠️`)
 var ini = antifigu.indexOf(m.chat)
antifigu.splice(ini, 1)
fs.writeFileSync('./funçoes/antitravas/antifigu.json', JSON.stringify(antifigu))
m.reply(`➥ Anti-figurinha desativado com sucesso! ❌`)
} else if (!q) {
enviarbuton(m.chat, `[⚠️] ANTI FIGURINHA [⚠️]\n\n• 𝙀𝙨𝙨𝙚 𝙧𝙚𝙘𝙪𝙧𝙨𝙤 𝙖𝙩𝙞𝙫𝙖𝙙𝙤, 𝙛𝙖𝙧𝙖̃ 𝙦𝙪𝙚 𝙤 𝙗𝙤𝙩 𝙧𝙚𝙢𝙤𝙫𝙖 𝙤 𝙪𝙨𝙪́𝙖𝙧𝙞𝙤 𝙦𝙪𝙚 𝙚𝙣𝙫𝙞𝙖𝙧 𝙛𝙞𝙜𝙪𝙧𝙞𝙣𝙝𝙖 𝙣𝙤 𝙜𝙧𝙪𝙥𝙤.`, `Selecione uma opção abaixo`, [{ quickReplyButton: { displayText: `Ativar ✅`, id: `${prefixo + command} on` } }, { quickReplyButton: { displayText: `Desativar ❌`, id: `${prefixo + command} off` } }])

}
}
break
case 'desativarall': {
if (!m.isGroup) return m.reply(msg.grupo)
if (!isBotAdmins) return m.reply(msg.botAdmin)
if (!isAdmins && !isDono) return m.reply(msg.admin)
//await sleep(200)
var ini = antifigu.indexOf(m.chat)
antifigu.splice(ini, 1)
fs.writeFileSync('./funçoes/antitravas/antifigu.json', JSON.stringify(antifigu))
//await sleep(200)
var ini2 = antifoto.indexOf(m.chat)
antifoto.splice(ini2, 1)
fs.writeFileSync('./funçoes/antitravas/antifoto.json', JSON.stringify(antifoto))
//await sleep(200)
var ini3 = antiloc.indexOf(m.chat)
antiloc.splice(ini3, 1)
fs.writeFileSync('./funçoes/antitravas/antiloc.json', JSON.stringify(antiloc))
//await sleep(200)
 var ini4 = antivideo.indexOf(m.chat)
antivideo.splice(ini4, 1)
fs.writeFileSync('./funçoes/antitravas/antivideo.json', JSON.stringify(antivideo))
//await sleep(200)
 var ini5 = anticat.indexOf(m.chat)
anticat.splice(ini5, 1)
fs.writeFileSync('./funçoes/antitravas/anticat.json', JSON.stringify(anticat))
//await sleep(200)
 var ini6 = antiaudio.indexOf(m.chat)
antiaudio.splice(ini6, 1)
fs.writeFileSync('./funçoes/antitravas/antiaudio.json', JSON.stringify(antiaudio))
//await sleep(200)
 var ini7 = antidoc.indexOf(m.chat)
antidoc.splice(ini7, 1)
fs.writeFileSync('./funçoes/antitravas/antidoc.json', JSON.stringify(antidoc))
//await sleep(200)
 var ini8 = anticon.indexOf(m.chat)
anticon.splice(ini8, 1)
fs.writeFileSync('./funçoes/antitravas/anticon.json', JSON.stringify(anticon))
/*await sleep(200)
 var ini9 = antilink.indexOf(m.chat)
antilink.splice(ini9, 1)
fs.writeFileSync('./funçoes/antilink/antilink.json', JSON.stringify(antilink)) */
m.reply(`➥ Todos os sistemas de proteção foram desativado!`)
}
break 
case 'ativarall': {
if (!m.isGroup) return m.reply(msg.grupo)
if (!isBotAdmins) return m.reply(msg.botAdmin)
if (!isAdmins && !isDono) return m.reply(msg.admin)
//await sleep(200)
antifigu.push(m.chat)
fs.writeFileSync('./funçoes/antitravas/antifigu.json', JSON.stringify(antifigu))
/*await sleep(200)
antilink.push(m.chat)
fs.writeFileSync('./funçoes/antilink/antilink.json', JSON.stringify(antilink)) */
//await sleep(200)
antiloc.push(m.chat)
fs.writeFileSync('./funçoes/antitravas/antiloc.json', JSON.stringify(antiloc))
//await sleep(200)
antidoc.push(m.chat)
fs.writeFileSync('./funçoes/antitravas/antidoc.json', JSON.stringify(antidoc))
//await sleep(200)
anticon.push(m.chat)
fs.writeFileSync('./funçoes/antitravas/anticon.json', JSON.stringify(anticon))
//await sleep(200)
antiaudio.push(m.chat)
fs.writeFileSync('./funçoes/antitravas/antiaudio.json', JSON.stringify(antiaudio))
//await sleep(200)
antivideo.push(m.chat)
fs.writeFileSync('./funçoes/antitravas/antivideo.json', JSON.stringify(antivideo))
//await sleep(200)
antifoto.push(m.chat)
fs.writeFileSync('./funçoes/antitravas/antifoto.json', JSON.stringify(antifoto))
//await sleep(200)
anticat.push(m.chat)
fs.writeFileSync('./funçoes/antitravas/anticat.json', JSON.stringify(anticat))
m.reply(`➥ Todos os sistemas de proteção foram ativado!`)
}
break
case 'gpsistema': case 'gppainel': case 'painelgp': case 'painelgrupo': {
// if (!isRegistrar) return m.reply(semreg)
if (!m.isGroup) return m.reply (msg.grupo)
if (!isBotAdmins) return m.reply(msg.botAdmin)
if (!isAdmins && !isDono) return m.reply(msg.admin)
 //   blaimg = await getBuffer(res.all[0].image)  
blaa = `🛡 ️ᴘᴀɪɴᴇʟ ᴅᴇ ᴘʀᴏᴛᴀᴄ̧ᴀ̃ᴏ 🛡️
┏━━━━━━━━━━━━━★
┃╭────────────╮
┃│➥ Anti-link: ${antlinkk}
┃│➥ Anti-fig: ${figurinhaa}
┃│➥ Anti-cat: ${catalogoo}
┃│➥ Anti-loc: ${localizacaoo}
┃│➥ Anti-doc: ${documentoo}
┃│➥ Anti-con: ${contatoo}
┃│➥ Anti-foto: ${fotoo}
┃│➥ Anti-video: ${videoo}
┃│➥ Anti-audio: ${audioo}
┃╰────────────╯
┗━━━━━━━━━━━━━★`
sendBimg(m.chat, `https://telegra.ph/file/c22fd68598850d1c8017c.jpg`, blaa, "Sistema de proteção do grupo!", [
{buttonId: `${prefixo}ativarall`, buttonText: {displayText: `Ativar`}, type: 1}, {buttonId: `${prefixo}desativarall`, buttonText: {displayText: `Desativar`}, type: 2}], m)
}
break
case 'gtoken': {
      if (!isDono) return m.reply(msg.dono)
//     name2x = randomText(8)
      key2x = randomText(12)
      add_usuario(key2x, "usuariommmsds", key2x);
      txt = `❗「 TOKEN GERADO 」❗
      
🗝️ TOKEN: *${key2x}*

🕵️ APIS DE CONSULTAS 🕵️

TELEFONE

https://mr-ubutu.herokuapp.com/puxar?type=telefone&q=11932853601&token=${key2x}

TELEFONE (2)

https://mr-ubutu.herokuapp.com/puxar?type=tel1&q=11932853601&token=${key2x}

TELEFONE (3)

https://mr-ubutu.herokuapp.com/puxar?type=tel2&q=11932853601&token=${key2x}

TELEFONE (4)

https://mr-ubutu.herokuapp.com/puxar?type=tel3&q=11932853601&token=${key2x}

CPF

https://mr-ubutu.herokuapp.com/puxar?type=cpf&q=45317828791&token=${key2x}

CPF1

https://mr-ubutu.herokuapp.com/puxar?type=cpf1&q=45317828791&token=${key2x}

CPF2

https://mr-ubutu.herokuapp.com/puxar?type=cpf2&q=08385265783&token=${key2x}

CPF3

https://mr-ubutu.herokuapp.com/puxar?type=cpf3&q=45317828791&token=${key2x}

CPF4

https://mr-ubutu.herokuapp.com/puxar?type=cpf4&q=45317828791&token=${key2x}

SCORE

https://mr-ubutu.herokuapp.com/puxar?type=score&q=08385265783&token=${key2x}

NOME

https://mr-ubutu.herokuapp.com/puxar?type=nome&q=Jair%20Messias%20Bolsonaro&token=${key2x}

NOME2

https://mr-ubutu.herokuapp.com/puxar?type=nome2&q=Jair%20Messias%20Bolsonaro&token=${key2x}

NOME3

https://mr-ubutu.herokuapp.com/puxar?type=nome3&q=Jair%20Messias%20Bolsonaro&token=${key2x}

PLACA

https://mr-ubutu.herokuapp.com/puxar?type=placa&q=JYE9708&token=${key2x}

CNPJ

https://mr-ubutu.herokuapp.com/puxar?type=cnpj&q=39708509000129&token=${key2x}

CNS

https://mr-ubutu.herokuapp.com/puxar?type=cns&q=703106349459960&token=${key2x}


VIZINHOS

https://mr-ubutu.herokuapp.com/puxar?type=vizinhos&q=08385265783&token=${key2x}

BIN

https://mr-ubutu.herokuapp.com/puxar?type=bin&q=498409&token=${key2x}`

  buttons = [
  {buttonId: `${prefixo}deltoken ${key2x}`, buttonText: {displayText: `DELETAR TOKEN 🗑️`}, type: 1},
  {buttonId: `${prefixo}copiartk ${txt}`, buttonText: {displayText: `COPIAR 📋`}, type: 1}
  ]
   buttonMessage = {
  text: txt,
  footer: `Para deletar use: /deltoken ${key2x}`,
  buttons: buttons,
  headerType: 2
  }
  client.sendMessage(m.chat, buttonMessage, { quoted: m })
}
    break
    case 'deltoken': {
      if (!isDono) return m.reply(msg.dono)
      reload = randomText(99)
      await changeKey(`${text}`, `${reload}off_`)
      m.reply(`➥ Token deletado com sucesso!`)      
    }
  break
/*        
case 'premium': {
    if (args[1] === 'add'){
        let usersv52 = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+''
const nmrmarcado2 = usersv52.replace("@s.whatsapp.net", "")
var username = nmrmarcado2
var password = "usuario123"
var confirmPassword = "usuario123"
        if (password.length < 6 || confirmPassword < 6) {
           m.reply('Senha precisa ter no mínimo 6 letras');
        }
            let checking = await verificar_nome(username);
            if(checking) {
                //m.reply('O número marcado ja tem registro, mas estou adicionando premium!');
                expired = "30"
                customKey = nmrmarcado2
               let checking = await verificar_nome(username);
               if (!checking) {
                   m.reply('Usuário não registrado/encontrado');
               } else {
                   let checkPrem = await checkPremium(username)
                   if (checkPrem) {
                       m.reply('O número marcado ja tem premium!');
                   } else {
                       addPremium(username, customKey, expired)
                       m.reply(`*ATUALIZAÇÃO NA DATABASE*\n\n📞 Número: ${username}\n👑 Status: Premium Adicionado :)`);
                       m.reply(`KEY GERADA COM SUCESSO

KEY: ${username}

TELEFONE

https://mr-ubutu.herokuapp.com/puxar?type=telefone&q=11932853601&token=${username}

TELEFONE (2)

https://mr-ubutu.herokuapp.com/puxar?type=tel1&q=11932853601&token=${username}

TELEFONE (3)

https://mr-ubutu.herokuapp.com/puxar?type=tel2&q=11932853601&token=${username}

TELEFONE (4)

https://mr-ubutu.herokuapp.com/puxar?type=tel3&q=11932853601&token=${username}

CPF

https://mr-ubutu.herokuapp.com/puxar?type=cpf&q=45317828791&token=${username}

CPF1

https://mr-ubutu.herokuapp.com/puxar?type=cpf1&q=45317828791&token=${username}

CPF2

https://mr-ubutu.herokuapp.com/puxar?type=cpf2&q=08385265783&token=${username}

CPF3

https://mr-ubutu.herokuapp.com/puxar?type=cpf3&q=45317828791&token=${username}

CPF4

https://mr-ubutu.herokuapp.com/puxar?type=cpf4&q=45317828791&token=${username}

SCORE

https://mr-ubutu.herokuapp.com/puxar?type=score&q=08385265783&token=${username}

NOME

https://mr-ubutu.herokuapp.com/puxar?type=nome&q=Jair%20Messias%20Bolsonaro&token=${username}

NOME2

https://mr-ubutu.herokuapp.com/puxar?type=nome2&q=Jair%20Messias%20Bolsonaro&token=${username}

NOME3

https://mr-ubutu.herokuapp.com/puxar?type=nome3&q=Jair%20Messias%20Bolsonaro&token=${username}

PLACA

https://mr-ubutu.herokuapp.com/puxar?type=placa&q=JYE9708&token=${username}

CNPJ

https://mr-ubutu.herokuapp.com/puxar?type=cnpj&q=39708509000129&token=${username}

CNS

https://mr-ubutu.herokuapp.com/puxar?type=cns&q=703106349459960&token=${username}


VIZINHOS

https://mr-ubutu.herokuapp.com/puxar?type=vizinhos&q=08385265783&token=${username}

BIN

https://mr-ubutu.herokuapp.com/puxar?type=bin&q=498409&token=${username}`)
                       
                   }
               }
            } else {
                let hashedPassword2 = getHashedPassword(password);
                let apikey = randomText(8);
                add_usuario(username, hashedPassword2, apikey);
              //  m.reply('Usuario registrado!');
               expired = "30"
               customKey = nmrmarcado2
              let checking = await verificar_nome(username);
              if (!checking) {
                  m.reply('Usuário não registrado/encontrado');
              } else {
                  let checkPrem = await checkPremium(username)
                  if (checkPrem) {
                      m.reply('O número marcado ja tem premium!');
                  } else {
                      addPremium(username, customKey, expired)
                      m.reply(`*ATUALIZAÇÃO NA DATABASE*\n\n📞 Número: ${username}\n👑 Status: Premium Adicionado :)`);
                       
                  }
              }
            }
}
if (args[1] === 'del'){
    let usersv53 = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+''
 nmrmarcado = usersv53.replace("@s.whatsapp.net", "")
 username = nmrmarcado
    let checking = await verificar_nome(username);
    if (!checking) {
        m.reply('O número marcado nem registrado esta.');
    } else {
        let checkPrem = await checkPremium(username)
        if (checkPrem) {
            deletePremium(username);
            m.reply(`*ATUALIZAÇÃO NA DATABASE*\n\n📞 Número: ${username}\n👑 Status: Premium Retirado :(`);
            
        } else {
            m.reply('Este usuário não e Premium');
        }
    };
}
}
    break        
*/        
           case 'list': case '?': case 'menu': case 'consultas': {
   // if (!isRegistrar) return m.reply(semreg)
   sections = [
{
title: "~> 𝘾𝙊𝙉𝙎𝙐𝙇𝙏𝘼𝙍 𝙏𝙀𝙇𝙀𝙁𝙊𝙉𝙀 📞 (5 Módulos)",
rows: [
{title: `${prefixo}Telefone`, rowId: "/tel", description: "Digite o telefone do alvo, irei pegar os dados desse telefone."},
{title: `${prefixo}Telefone2`, rowId: "/tel2", description: "Digite o telefone do alvo, irei pegar os dados desse telefone."},
{title: `${prefixo}Telefone3`, rowId: "/tel3", description: "Digite o telefone do alvo, irei pegar os dados desse telefone."},
{title: `${prefixo}Telefone4`, rowId: "/tel4", description: "Digite o telefone do alvo, irei pegar os dados desse telefone."},
{title: `${prefixo}Puxar`, rowId: "/puxar", description: "Digite /puxar e marque uma pessoa."},
]
},
   {
title: "~> 𝘾𝙊𝙉𝙎𝙐𝙇𝙏𝘼𝙍 𝘾𝙋𝙁 👤 (4 Módulos)",
rows: [
{title: `${prefixo}Cpf`, rowId: "/cpf", description: "Esse comando realiza uma consulta simples de determinado CPF."},
{title: `${prefixo}Cpf1`, rowId: "/cpf1", description: "Esse comando realiza uma consulta média de determinado CPF."},
{title: `${prefixo}Cpf2`, rowId: "/cpf2", description: "Esse comando realiza uma consulta média de determinado CPF."},
{title: `${prefixo}Cpf3`, rowId: "/cpf3", description: "Esse comando realiza uma consulta completa de determinado CPF."},
]
},
{
title: "~> 𝘾𝙊𝙉𝙎𝙐𝙇𝙏𝘼𝙍 𝙎𝘾𝙊𝙍𝙀 📊️",
rows: [
{title: `${prefixo}Score`, rowId: "/score", description: "Esse comando busca o score e renda de determinado CPF."},
]
},
{
title: "~> 𝘾𝙊𝙉𝙎𝙐𝙇𝙏𝘼𝙍 𝙉𝙊𝙈𝙀 🖌 ️(3 Módulos)",
rows: [
{title: `${prefixo}Nome`, rowId: "/nome", description: "Esse comando realiza uma consulta simples em determinado nome."},
{title: `${prefixo}Nome2`, rowId: "/nome2", description: "Esse comando realiza uma consulta simples em determinado nome."},
{title: `${prefixo}Nome3`, rowId: "/nome3", description: "Esse comando realiza uma consulta simples em determinado nome."},

]

},
{
title: "~> 𝘾𝙊𝙉𝙎𝙐𝙇𝙏𝘼𝙍 𝘾𝙉𝙋𝙅 📑 (2 Módulos)",
rows: [
{title: `${prefixo}Cnpj`, rowId: "/cnpj", description: "Puxada Simples"},
{title: `${prefixo}Cnpj2`, rowId: "/cnpj2", description: "Puxada Completa"},

]

},
{
title: "~> 𝘾𝙊𝙉𝙎𝙐𝙇𝙏𝘼𝙍 𝙋𝙇𝘼𝘾𝘼 🔤 (2 Módulos)",
rows: [
{title: `${prefixo}Placa`, rowId: "/placa", description: "Consulte tudo de uma placa!"},
{title: `${prefixo}Placa2`, rowId: "/placa2", description: "Consulte tudo de uma placa!"},

]

},
{
title: "~> 𝘾𝙊𝙉𝙎𝙐𝙇𝙏𝘼𝙍 𝘾𝙉𝙎 ️🎰",
rows: [
{title: `${prefixo}Cns`, rowId: "/cns", description: "Consulte um cns facilmente!"},

]

},
{
title: "~> 𝘾𝙊𝙉𝙎𝙐𝙇𝙏𝘼𝙍 𝙑𝙄𝙕𝙄𝙉𝙃𝙊𝙎 ️👥",
rows: [
{title: `${prefixo}Vizinhos`, rowId: "/vizinhos", description: "Consulte os vizinhos de um determinado cpf!"},

]

},
{
title: "~> 𝘾𝙃𝙀𝘾𝙆𝙀𝙍 𝙂𝙂 💳️",
rows: [
{title: `${prefixo}Chkgg`, rowId: "/chkgg", description: "Checker de Cartões de Crédito ou Débito gerados"},

]

},
{
title: "~> 𝘾𝙊𝙉𝙎𝙐𝙇𝙏𝘼𝙍 𝙂𝙍𝘼𝙏𝙄𝙎 🆓",
rows: [
{title: `${prefixo}Ip`, rowId: "/ip", description: "Consulte um ip!"},
{title: `${prefixo}Cep`, rowId: "/cep", description: "Pegue a localização exata de tal cep!"},
{title: `${prefixo}Bin`, rowId: "/bin", description: "Consulte uma bin!"},

]

},
{
title: "~> 𝙄𝙉𝙁𝙊 𝘿𝙊 𝘽𝙊𝙏 🤖",
rows: [
{title: "➧ Grupo do Bot", rowId: "/gbot", description: "Consultas Gratuitas"},
{title: "➧ Loja do Bot 🛒", rowId: "/store", description: "Planos, Apis, Script"},
{title: "➧ Revendedores Oficiais ©", rowId: "/dono", description: "Criadores, e revendedores oficiais!"},

]

}
]

 txtf = `━━━━━━━━━━━━━━━━━━
🔘 Contrate agora o mais completo bot de consultas.
 
🔘 Consultas online 24h por dia.

🔘 Pague através do boleto ou Pix.
━━━━━━━━━━━━━━━━━━`
listMessage = {
   
  text: txtf,
  footer: "Clique no botão abaixo para ver as consultas disponíveis",
  title: "*🕵️ MENU DE CONSULTAS 🕵️*",
  buttonText: "Clique para ver️ 🖱️", 
  sections
}

client.sendMessage(m.chat, listMessage, {quoted: m})
}  
break                  

                case 'burlar': {
               if (!isDono && !isPremium2) return m.reply(`➥ Somente usuário premium pode utilizar esse comando!`)
               usuario.consultas = -1
               console.log("Eliminado do tempo de espera")
               m.reply(`➥ Você burlou o tempo de espera com sucesso!`)
               }
               break
          
          case 'desbug': {
          if (!isDono) return m.reply(msg.dono)              
              let uers = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'' 
              let user99 = global.db.data.users[uers]
              let nmrmencionado = uers.replace("@s.whatsapp.net", "")
              if (!nmrmencionado) return m.reply(`➥ Marque um usuário ou digite o número!`)
              user99.consultas = -1
              console.log(nmrmencionado + " Eliminado do tempo de espera")
              m.reply(`➥ Você resetou o tempo de espera do usuário ${nmrmencionado}!`)
          }
          break
          case 'revendedores': case 'dono': case 'criador': {
                client.sendContact(m.chat, global.owner, m)
            }
            break

case 'apisc': case 'apis': case 'preçosapis': case 'preçoapi': case 'preçosapi': {
          //   if (!isRegistrar) return m.reply(semreg)     
          anu = `━━━━━━━━━━━━━━━━━━
𝗔𝗣𝗜𝗦 𝗗𝗘 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔𝗦 🛒
                    
VALORES: 

🔘 TELEFONE(2,3,4)
🔘 CPF (1,2,3,4) 
🔘 NOME (2,3)
🔘 SCORE 
🔘 VIZINHOS 
🔘 CNS 
🔘 CNPJ
🔘 PLACA 
🔘 BIN 

MENSAL: R$110
SEMANAL: R$35

━━━━━━━━━━━━━━━━━━

REVENDEDORES OFICIAIS:`
let messagex = await prepareWAMessageMedia({ image: fs.readFileSync('./funçoes/media/preços.png') }, { upload: client.waUploadToServer })
const templatex = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
templateMessage: {
hydratedTemplate: {
imageMessage: messagex.imageMessage,
hydratedContentText: anu,
hydratedButtons: [{
urlButton: {
displayText: 'MrRoots ©',
url: 'https://api.whatsapp.com/send?phone=554891089432&text=Olá+Mr%2c+tenho+interesse+de+comprar+as+apis+de+consultas!'
}
}, {
urlButton: {
displayText: 'Júnior ©',
url: 'https://api.whatsapp.com/send?phone=558588631124&text=Olá+Júnior%2c+tenho+interesse+de+comprar+as+apis+de+consultas!'
}
}, {
urlButton: {
displayText: 'KrMarley ©',
url: 'https://api.whatsapp.com/send?phone=554891129768&text=Olá+Karol%2c+tenho+interesse+de+comprar+as+apis+de+consultas!'
}                                

}]
}
}
}), { userJid: m.chat, m })
client.relayMessage(m.chat, templatex.message, fake, { messageId: templatex.key.id })
}
break
  case 'basec': case 'script': case 'scriptbot': {
         //   if (!isRegistrar) return m.reply(semreg)     
         anu = `━━━━━━━━━━━━━━━━━━
𝗕𝗔𝗦𝗘 𝗘𝗗𝗜𝗧𝗔𝗩𝗘𝗟 🛒
                    
VALORES: 

🔘 COM ATUALIZAÇÕES - R$80,00
🔘 SEM ATUALIZAÇÕES - R$50,00

━━━━━━━━━━━━━━━━━━

VENDEDORES OFICIAIS:`
let messagex = await prepareWAMessageMedia({ image: fs.readFileSync('./funçoes/media/arquivo.png') }, { upload: client.waUploadToServer })
const templatex = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
templateMessage: {
hydratedTemplate: {
imageMessage: messagex.imageMessage,
hydratedContentText: anu,
hydratedButtons: [{
urlButton: {
displayText: 'MrRoots ©',
url: 'https://api.whatsapp.com/send?phone=554891089432&text=Olá+Mr%2c+tenho+interesse+de+comprar+a+script+editável+do+bot!'
}
}, {
urlButton: {
displayText: 'Júnior ©',
url: 'https://api.whatsapp.com/send?phone=558588631124&text=Olá+Júnior%2c+tenho+interesse+de+comprar+a+script+editável+do+bot!'
}
}, {
urlButton: {
displayText: 'KrMarley ©',
url: 'https://api.whatsapp.com/send?phone=554891129768&text=Olá+Karol%2c+tenho+interesse+de+comprar+a+script+editável+do+bot!'
} 
}]
}
}
}), { userJid: m.chat, quoted: m })
client.relayMessage(m.chat, templatex.message, { messageId: templatex.key.id })
}
break
           case 'lojadobot': case 'loja': case 'store': {
            //   if (!isRegistrar) return m.reply(semreg)     
           anu = `━━━━━━━━━━━━━━━━━━
LOJA - 𝗙𝗟𝗔𝗬 𝗥𝗢𝗕𝗢𝗧 🛒
                    
VENDAS DISPONÍVEIS: 

🔘 Apis de consulta
🔘 Base editavel
🔘 Planos individual/grupos

━━━━━━━━━━━━━━━━━━`
let messagex = await prepareWAMessageMedia({ image: fs.readFileSync('./funçoes/media/preços.png') }, { upload: client.waUploadToServer })
const templatex = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
templateMessage: {
hydratedTemplate: {
imageMessage: messagex.imageMessage,
hydratedContentText: anu,
hydratedButtons: [{
quickReplyButton: {
displayText: 'Apis de Consultas 🔗',
id: 'apisc'
}
}, {
quickReplyButton: {
displayText: 'Base Editável ⚙️',
id: 'basec'
}  
}, {
quickReplyButton: {
displayText: 'Plano 👑',
id: 'preços'
}                                

}]
}
}
}), { userJid: m.chat, quoted: m })
client.relayMessage(m.chat, templatex.message, { messageId: templatex.key.id })
}
break

  case 'preços': case 'plano': case 'valores': {
 //   if (!isRegistrar) return m.reply(semreg) 
anupreços = `☑️ 𝗣𝗟𝗔𝗡𝗢𝗦 𝗘 𝗩𝗔𝗟𝗢𝗥𝗘𝗦

NA PRIMEIRA COMPRA VOCÊ PAGA R$15 REAIS VÁLIDO POR 1 MÊS! 

━━━━━━━━━━━━━━━━━━
⚜ CONSULTAS DISPONÍVEIS

🔘 CPF
🔘 CNS
🔘 CNPJ
🔘 BIN
🔘 CEP
🔘 SCORE
🔘 NOME
🔘 PLACA 
🔘 TELEFONE

━━━━━━━━━━━━━━━━━━
⚜ CONSULTAS ILIMITADA  

🔘 FAÇA CONSULTAS SEM LIMITE

━━━━━━━━━━━━━━━━━━
⚜ PLANOS  INDIVIDUAIS

🔘 07 DIAS = R$ 10,00
🔘 15 DIAS = R$ 20,00
🔘 30 DIAS = R$ 35,00

━━━━━━━━━━━━━━━━━━
⚜ PLANOS PARA GRUPOS

🔘 07 DIAS = R$ 15,00
🔘 15 DIAS = R$ 30,00
🔘 30 DIAS = R$ 50,00

━━━━━━━━━━━━━━━━━━
⚜ FORMAS DE PAGAMENTO

🔘 BOLETO
🔘 TRANSFERÊNCIA PIX

━━━━━━━━━━━━━━━━━━

VENDEDORES OFICIAIS:`
let messagex = await prepareWAMessageMedia({ image: fs.readFileSync('./funçoes/media/grupos.jpeg') }, { upload: client.waUploadToServer })
const templatex = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
templateMessage: {
hydratedTemplate: {
imageMessage: messagex.imageMessage,
hydratedContentText: anupreços,
hydratedButtons: [{
urlButton: {
displayText: 'MrRoots ©',
url: 'https://api.whatsapp.com/send?phone=554891089432&text=Olá+Mr%2c+tenho+interesse+de+comprar+plano+no+bot!'
}
}, {
urlButton: {
displayText: 'Júnior ©',
url: 'https://api.whatsapp.com/send?phone=558588631124&text=Olá+Júnior%2c+tenho+interesse+de+comprar+plano+no+bot!'
}
}, {
urlButton: {
displayText: 'KrMarley ©',
url: 'https://api.whatsapp.com/send?phone=554891129768&text=Olá+Karol%2c+tenho+interesse+de+comprar+plano+no+bot!'
} 
}]
}
}
}), { userJid: m.chat, quoted: m })
client.relayMessage(m.chat, templatex.message, { messageId: templatex.key.id })
}
break

case 'getid': {
// if (!isRegistrar) return m.reply(semreg)
m.reply(m.chat)
}
break
case 'checkgp': {
    if (!m.isGroup) return m.reply(msg.grupo)
    if (!isPremiumGp) {
      m.reply(`➥ Não, Esse grupo não tem Premium!`)
    } else {
        m.reply(`➥ Sim, Esse grupo tem Premium!`)
    }
    }
    break
case 'check': {
    if(!isPremium2) {
      m.reply(`➥ Não, Você não tem Premium!`)
    } else {
        m.reply(`➥ Sim, Voce tem Premium!`)
    }
    }
    break     
           
 case 'puxar': {
if (!isPremiumGp && !isPremium2) return noprem(`Somente usuário premium pode utilizar comandos de consultas!`)
let user3 = global.db.data.users[m.sender]
if (user3.consultas != -1) {
tempo_de_espera = clockString(new Date - user3.consultas).replace("00:00:", " ")
m.reply(`➥ Aguarde 30 segundos para consultar novamente!\n\nTempo já passado: ${tempo_de_espera} segundos ⌛`)
 } else {
   let uers = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+''
var exemplo = "Aprendendo JavaScript na DevMedia!";
var resultad = uers.replace("@s.whatsapp.net", "");
var resultad2 = resultad.replace("55", "");
var resultad3 = resultad2.replace(/(\d{2})/, "$19")
const checkmm = uers ? 's' : 'n' 
if (checkmm != 's')  return m.reply(`➥ Marque o @ de uma pessoa do grupo ou marque uma mensagem com: ${prefixo+command}`)
if(resultad2.length < 11 || resultad2.length > 11) {
console.log(`~> Consultando o número ${texto}`)
await cliente(msg_espera)
await sleep(500)
await reagir(m.chat, m.key, "🕗")
apixx = await fetchJson(`https://mr-ubutu.herokuapp.com/puxar?type=tel1&q=${resultad3}&token=${tokenvip}`)
if (apixx.resultado != undefined) {
str = apixx.resultado.replace(
`USUÁRIO: ﾠ `,
`\n\n👑 Usuário: ${pushname} ${pushname}\n\n 🔛 BY: ${fake}\n\n═════════════════════`
);
str2 = apixx.resultado.replace(
`𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗧𝗘𝗟𝗘𝗙𝗢𝗡𝗘`,
`═════════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗧𝗘𝗟𝗘𝗙𝗢𝗡𝗘 🕵️
═════════════════════`
);


consult(`═════════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗧𝗘𝗟𝗘𝗙𝗢𝗡𝗘 🕵️
═════════════════════

${apixx.resultado}
  
👑 Usuário: ${pushname}

🔛 BY: ${fake}

═════════════════════`)
} else {
await sleep(50)
m.reply(`⚠️ TELEFONE NÃO ENCONTRADO!`)  
} 
} else {
console.log(`~> Consultando o número ${texto}`)
await cliente(msg_espera)
await sleep(500)
await reagir(m.chat, m.key, "🕗")
apixx = await fetchJson(`https://mr-ubutu.herokuapp.com/puxar?type=tel1&q=${resultad2}&token=${tokenvip}`)
if (apixx.resultado != undefined) {
  str = apixx.resultado.replace(
`USUÁRIO: ﾠ `,
`\n\nUSÚARIO: ${pushname}\n\n🔛 BY: ${fake}\n\n═════════════════════`
);


consult(`═════════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗧𝗘𝗟𝗘𝗙𝗢𝗡𝗘 🕵️
═════════════════════

${apixx.resultado}
  
👤 Usuário: ${pushname}

🔛 BY: ${fake}

═════════════════════`)
} else {
await sleep(50)
m.reply(`⚠️ TELEFONE NÃO ENCONTRADO!`)  
}
}
}
}
break           

case 'tel': 
case 'telefone': {
if (!isPremiumGp && !isPremium2) return noprem(`Somente usuário premium pode utilizar comandos de consultas!`)
let user3 = global.db.data.users[m.sender]
if (user3.consultas != -1) {
tempo_de_espera = clockString(new Date - user3.consultas).replace("00:00:", " ")
m.reply(`➥ Aguarde 30 segundos para consultar novamente!\n\nTempo já passado: ${tempo_de_espera} segundos ⌛`)
} else {
if (!texto) return m.reply(`🔍 CONSULTA VIP 🔍
━━━━━━━━━━━━━━━━━━
╭──────────────
┇   𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗧𝗘𝗙𝗘𝗙𝗢𝗡𝗘:  
╰──────────────

Você precisa digitar o comando e em seguida, digitar os 11 números do telefone incluindo o 9.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} 11932853601
━━━━━━━━━━━━━━━━━━`)
var query = texto
.split('+').join('')
.split('-').join('')
.split(' ').join('')
.split('(').join('')
.split(')').join('');
var resultad2 = texto.replace("55", "");
var resultad3 = resultad2.replace(/(\d{2})/, "$19")
if (query.length >= 12) return m.reply(`➥ Número inválido ou incorreto!`)
if (query.length < 11 || query.length > 11) return m.reply(`⚠️ FORMATO INCORRETO ⚠️
━━━━━━━━━━━━━━━━━━

O número que você digitou está inválido ou incorreto!

❌ Errado: ${resultad2}
✅️ Correto: ${resultad3}

• Use o comando novamente com o número no formato correto.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} ${resultad3}
━━━━━━━━━━━━━━━━━━`)
console.log(`~> Consultando o número ${texto}`)
await cliente(msg_espera)
await sleep(500)
await reagir(m.chat, m.key, "🕗")
api_tel = await fetchJson(`https://mr-ubutu.herokuapp.com/puxar?type=telefone&q=${texto}&token=${tokenvip}`)
if (api_tel.resultado != undefined) {
consult(`═════════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗧𝗘𝗟𝗘𝗙𝗢𝗡𝗘 🕵️
═════════════════════

${api_tel.resultado}

👑 Usuário: ${pushname}

🔛 BY: ${fake}

═════════════════════`)
} else {
     m.reply(`⚠️ TELEFONE NÃO ENCONTRADO!`)
}
}
}
break
case 'tel2': 
case 'telefone2': {
if (!isPremiumGp && !isPremium2) return noprem(`Somente usuário premium pode utilizar comandos de consultas!`)
let user3 = global.db.data.users[m.sender]
if (user3.consultas != -1) {
tempo_de_espera = clockString(new Date - user3.consultas).replace("00:00:", " ")
m.reply(`➥ Aguarde 30 segundos para consultar novamente!\n\nTempo já passado: ${tempo_de_espera} segundos ⌛`)
 } else {
if (!texto) return m.reply(`🔍 CONSULTA VIP 🔍
━━━━━━━━━━━━━━━━━━
╭──────────────
┇   𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗧𝗘𝗙𝗘𝗙𝗢𝗡𝗘:  
╰──────────────

Você precisa digitar o comando e em seguida, digitar os 11 números do telefone incluindo o 9.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} 11932853601
━━━━━━━━━━━━━━━━━━`)
var query = texto
.split('+').join('')
.split('-').join('')
.split(' ').join('')
.split('(').join('')
.split(')').join('');
var resultad2 = texto.replace("55", "");
var resultad3 = resultad2.replace(/(\d{2})/, "$19")
if (query.length >= 12) return m.reply(`➥ Número inválido ou incorreto!`)
if (query.length < 11 || query.length > 11) return m.reply(`⚠️ FORMATO INCORRETO ⚠️
━━━━━━━━━━━━━━━━━━

O número que você digitou está inválido ou incorreto!

❌ Errado: ${resultad2}
✅️ Correto: ${resultad3}

• Use o comando novamente com o número no formato correto.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} ${resultad3}
━━━━━━━━━━━━━━━━━━`)
console.log(`~> Consultando o número ${texto}`)
await cliente(msg_espera)
await sleep(500)
await reagir(m.chat, m.key, "🕗")
api_tel = await fetchJson(`https://mr-ubutu.herokuapp.com/puxar?type=tel2&q=${texto}&token=${tokenvip}`)
if (api_tel.resultado != undefined) {
consult(`═════════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗧𝗘𝗟𝗘𝗙𝗢𝗡𝗘 🕵️
═════════════════════

${api_tel.resultado}

👑 Usuário: ${pushname}

🔛 BY: ${fake}

═════════════════════`)
} else {
     m.reply(`⚠️ TELEFONE NÃO ENCONTRADO!`)
}
}
}
break
case 'tel3': 
case 'telefone3': {
if (!isPremiumGp && !isPremium2) return noprem(`Somente usuário premium pode utilizar comandos de consultas!`)
let user3 = global.db.data.users[m.sender]
if (user3.consultas != -1) {
tempo_de_espera = clockString(new Date - user3.consultas).replace("00:00:", " ")
m.reply(`➥ Aguarde 30 segundos para consultar novamente!\n\nTempo já passado: ${tempo_de_espera} segundos ⌛`)
 } else {
if (!texto) return m.reply(`🔍 CONSULTA VIP 🔍
━━━━━━━━━━━━━━━━━━
╭──────────────
┇   𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗧𝗘𝗙𝗘𝗙𝗢𝗡𝗘:  
╰──────────────

Você precisa digitar o comando e em seguida, digitar os 11 números do telefone incluindo o 9.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} 11932853601
━━━━━━━━━━━━━━━━━━`)
var query = texto
.split('+').join('')
.split('-').join('')
.split(' ').join('')
.split('(').join('')
.split(')').join('');
var resultad2 = texto.replace("55", "");
var resultad3 = resultad2.replace(/(\d{2})/, "$19")
if (query.length >= 12) return m.reply(`➥ Número inválido ou incorreto!`)
if (query.length < 11 || query.length > 11) return m.reply(`⚠️ FORMATO INCORRETO ⚠️
━━━━━━━━━━━━━━━━━━

O número que você digitou está inválido ou incorreto!

❌ Errado: ${resultad2}
✅️ Correto: ${resultad3}

• Use o comando novamente com o número no formato correto.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} ${resultad3}
━━━━━━━━━━━━━━━━━━`)
console.log(`~> Consultando o número ${texto}`)
await cliente(msg_espera)
await sleep(500)
await reagir(m.chat, m.key, "🕗")
api_tel = await fetchJson(`https://mr-ubutu.herokuapp.com/puxar?type=tel3&q=${texto}&token=${tokenvip}`)
if (api_tel.resultado != undefined) {
consult(`═════════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗧𝗘𝗟𝗘𝗙𝗢𝗡𝗘 🕵️
═════════════════════

${api_tel.resultado}

👑 Usuário: ${pushname}

🔛 BY: ${fake}

═════════════════════`)
} else {
     m.reply(`⚠️ TELEFONE NÃO ENCONTRADO!`)
}
}
}
break
case 'tel4': 
case 'telefone4': {
if (!isPremiumGp && !isPremium2) return noprem(`Somente usuário premium pode utilizar comandos de consultas!`)
let user3 = global.db.data.users[m.sender]
if (user3.consultas != -1) {
tempo_de_espera = clockString(new Date - user3.consultas).replace("00:00:", " ")
m.reply(`➥ Aguarde 30 segundos para consultar novamente!\n\nTempo já passado: ${tempo_de_espera} segundos ⌛`)
 } else {
if (!texto) return m.reply(`🔍 CONSULTA VIP 🔍
━━━━━━━━━━━━━━━━━━
╭──────────────
┇   𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗧𝗘𝗙𝗘𝗙𝗢𝗡𝗘:  
╰──────────────

Você precisa digitar o comando e em seguida, digitar os 11 números do telefone incluindo o 9.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} 11932853601
━━━━━━━━━━━━━━━━━━`)
var query = texto
.split('+').join('')
.split('-').join('')
.split(' ').join('')
.split('(').join('')
.split(')').join('');
var resultad2 = texto.replace("55", "");
var resultad3 = resultad2.replace(/(\d{2})/, "$19")
if (query.length >= 12) return m.reply(`➥ Número inválido ou incorreto!`)
if (query.length < 11 || query.length > 11) return m.reply(`⚠️ FORMATO INCORRETO ⚠️
━━━━━━━━━━━━━━━━━━

O número que você digitou está inválido ou incorreto!

❌ Errado: ${resultad2}
✅️ Correto: ${resultad3}

• Use o comando novamente com o número no formato correto.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} ${resultad3}
━━━━━━━━━━━━━━━━━━`)
console.log(`~> Consultando o número ${texto}`)
await cliente(msg_espera)
await sleep(500)
await reagir(m.chat, m.key, "🕗")
api_tel = await fetchJson(`https://mr-ubutu.herokuapp.com/puxar?type=tel4&q=${texto}&token=${tokenvip}`)
if (api_tel.resultado != undefined) {
consult(`═════════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗧𝗘𝗟𝗘𝗙𝗢𝗡𝗘 🕵️
═════════════════════

${api_tel.resultado}

👑 Usuário: ${pushname}

🔛 BY: ${fake}

═════════════════════`)
} else {
     m.reply(`⚠️ TELEFONE NÃO ENCONTRADO!`)
}
}
}
break
case 'score': {
if (!isPremiumGp && !isPremium2) return noprem(`Somente usuário premium pode utilizar comandos de consultas!`)
let user3 = global.db.data.users[m.sender]
if (user3.consultas != -1) {
tempo_de_espera = clockString(new Date - user3.consultas).replace("00:00:", " ")
m.reply(`➥ Aguarde 30 segundos para consultar novamente!\n\nTempo já passado: ${tempo_de_espera} segundos ⌛`)
 } else {
 var query = texto
.split('.').join('')
.split('-').join('')
.split(' ').join('');
if (!texto) return m.reply(`🔍 CONSULTA VIP 🔍
━━━━━━━━━━━━━━━━━━
╭──────────────
┇   𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗦𝗖𝗢𝗥𝗘:  
╰──────────────

Você precisa digitar o comando e em seguida, digitar os 11 números do cpf da vítima que você deseja consultar o score.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} 00000000868
━━━━━━━━━━━━━━━━━━`)
if (query.length < 11 || query.length > 11) return m.reply(`⚠️ FORMATO INCORRETO ⚠️
━━━━━━━━━━━━━━━━━━

O cpf que você digitou não tem 11 dígitos!

❌ Formato incorreto:

014.414.520-01

✅ Formato correto:

01441452001

• Use o comando novamente com o cpf no formato correto.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} 00017500389
━━━━━━━━━━━━━━━━━━`)
await cliente(msg_espera)
await sleep(500)
await reagir(m.chat, m.key, "🕗")
console.log(`~> Consultando o score do cpf ${texto}`) 
let api_de_score = await fetchJson(`https://mr-ubutu.herokuapp.com/puxar?type=score&q=${texto}&token=${tokenvip}`)
//addl(nmrp);
if (api_de_score.resultado != undefined) {
    consult(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗦𝗖𝗢𝗥𝗘 🕵️
═════════════════

${api_de_score.resultado}

👑 Usuário: ${pushname}

🔛 BY: ${fake}

═════════════════`)
} else {
m.reply(`⚠ SCORE NÃO ENCONTRADO!`)  
}
}
}
  break

            case 'vizinhos': {
if (!isPremiumGp && !isPremium2) return noprem(`Somente usuário premium pode utilizar comandos de consultas!`)
let user3 = global.db.data.users[m.sender]
if (user3.consultas != -1) {
tempo_de_espera = clockString(new Date - user3.consultas).replace("00:00:", " ")
m.reply(`➥ Aguarde 30 segundos para consultar novamente!\n\nTempo já passado: ${tempo_de_espera} segundos ⌛`)
 } else {
var query = texto
.split('.').join('')
.split('-').join('')
.split(' ').join(''); 
if (!texto) return m.reply(`🔍 CONSULTA VIP 🔍
━━━━━━━━━━━━━━━━━━
╭──────────────
┇   𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗩𝗜𝗭𝗜𝗡𝗛𝗢𝗦:  
╰──────────────

Você precisa digitar o comando e em seguida, digitar os 11 números do CPF.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} 08385265783
━━━━━━━━━━━━━━━━━━`)
if (query.length < 11 || query.length > 11) return m.reply(`⚠️ FORMATO INCORRETO ⚠️
━━━━━━━━━━━━━━━━━━

O cpf que você digitou não tem 11 dígitos!

❌ Formato incorreto:

014.414.520-01

✅ Formato correto:

01441452001

• Use o comando novamente com o cpf no formato correto.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} 00017500389
━━━━━━━━━━━━━━━━━━`)
console.log(`~> Consultando os vizinhos do cpf ${texto}`)
await cliente(msg_espera)
await sleep(500)
await reagir(m.chat, m.key, "🕗")
let api_de_cpf = await fetchJson(`https://mr-ubutu.herokuapp.com/puxar?type=vizinhos&q=${texto}&token=${tokenvip}`)
if (api_de_cpf.resultado != undefined) {
    consult(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗩𝗜𝗭𝗜𝗡𝗛𝗢𝗦 🕵️
═════════════════

${api_de_cpf.resultado}
  
👑 Usuário: ${pushname}

🔛 BY: ${fake}

═════════════════`)
} else {
m.reply(`⚠ VIZINHOS NÃO ENCONTRADO!`)  
}
}
}
  break
case 'cpf':
  case 'cpf1':
    case 'cpf2':
        case 'cpf3':
            case 'cpf4': {
if (!isPremiumGp && !isPremium2) return noprem(`Somente usuário premium pode utilizar comandos de consultas!`)
let user3 = global.db.data.users[m.sender]
if (user3.consultas != -1) {
tempo_de_espera = clockString(new Date - user3.consultas).replace("00:00:", " ")
m.reply(`➥ Aguarde 30 segundos para consultar novamente!\n\nTempo já passado: ${tempo_de_espera} segundos ⌛`)
 } else {
var query = texto
.split('.').join('')
.split('-').join('')
.split(' ').join('');
if (!texto) return m.reply(`🔍 CONSULTA VIP 🔍
━━━━━━━━━━━━━━━━━━
╭──────────────
┇   𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗖𝗣𝗙:  
╰──────────────

Você precisa digitar o comando e em seguida, digitar os 11 números do CPF.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} 08385265783
━━━━━━━━━━━━━━━━━━`)
if (query.length < 11 || query.length > 11) return m.reply(`⚠️ FORMATO INCORRETO ⚠️
━━━━━━━━━━━━━━━━━━

O cpf que você digitou não tem 11 dígitos!

❌ Formato incorreto:

014.414.520-01

✅ Formato correto:

01441452001

• Use o comando novamente com o cpf no formato correto.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} 00017500389
━━━━━━━━━━━━━━━━━━`)
console.log(`~> Consultando o cpf ${texto}`)
await cliente(msg_espera)
await sleep(500)
await reagir(m.chat, m.key, "🕗")
let api_de_cpf = await fetchJson(`https://mr-ubutu.herokuapp.com/puxar?type=${command}&q=${texto}&token=${tokenvip}`)
if (api_de_cpf.resultado != undefined) {
    consult(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗖𝗣𝗙 🕵️
═════════════════

${api_de_cpf.resultado}
  
👑 Usuário: ${pushname}

🔛 BY: ${fake}

═════════════════`)
} else {
m.reply(`⚠ CPF NÃO ENCONTRADO!`)  
}
}
}
  break  

    case 'nome':
case 'name': {
if (!isPremiumGp && !isPremium2) return noprem(`Somente usuário premium pode utilizar comandos de consultas!`)
let user3 = global.db.data.users[m.sender]
if (user3.consultas != -1) {
tempo_de_espera = clockString(new Date - user3.consultas).replace("00:00:", " ")
m.reply(`➥ Aguarde 30 segundos para consultar novamente!\n\nTempo já passado: ${tempo_de_espera} segundos ⌛`)
 } else {
if (!text) return m.reply(`🔍 CONSULTA VIP 🔍
━━━━━━━━━━━━━━━━━━
╭──────────────
┇   𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗡𝗢𝗠𝗘:  
╰──────────────

Você precisa digitar o comando e em seguida, digite o nome completo da vítima que deseja procurar.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} Jair Messias Bolsonaro
━━━━━━━━━━━━━━━━━━`)
await cliente(msg_espera)
await sleep(500)
await reagir(m.chat, m.key, "🕗")
console.log(`~> Consultando o nome ${text}`)
api = await fetchJson(`https://mr-ubutu.herokuapp.com/puxar?type=nome&q=${text}&token=${tokenvip}`)
try {
var encodedStringAtoB = `${api.resultado.base64}`
var decodedStringAtoB = atob(encodedStringAtoB);
if (api.resultado.base64 == undefined) {
if (api.resultado == undefined) {
    m.reply("⚠️ NOME NÃO ENCONTRADO!")
} else {
ress = api.resultado
codando = ress.replace("𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗡𝗢𝗠𝗘", `═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗡𝗢𝗠𝗘 🕵️
═════════════════`).replace("🔛 BY: @Skynet02Robot", "")
consult(codando + "\n\n═════════════════")
}
} else {
consult(('═════════════════\n🕵️  CONSULTA REALIZADA  🕵️\n═════════════════\n\n• Nome(s) encontrado(s) na mnha db:\n' + decodedStringAtoB.replace(/\,|â¢/gi, "")))
}
} catch {
m.reply(`⚠️ NOME NÃO ENCONTRADO!`) //caso o tempo de resposta for excedido
}
}
}
  break
           case 'nome2': 
               case 'name2': {
if (!isPremiumGp && !isPremium2) return noprem(`Somente usuário premium pode utilizar comandos de consultas!`)
let user3 = global.db.data.users[m.sender]
if (user3.consultas != -1) {
tempo_de_espera = clockString(new Date - user3.consultas).replace("00:00:", " ")
m.reply(`➥ Aguarde 30 segundos para consultar novamente!\n\nTempo já passado: ${tempo_de_espera} segundos ⌛`)
 } else {
if (!texto) return m.reply(`🔍 CONSULTA VIP 🔍
━━━━━━━━━━━━━━━━━━
╭──────────────
┇   𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗡𝗢𝗠𝗘:  
╰──────────────

Você precisa digitar o comando e em seguida, digite o nome completo da vítima que deseja procurar.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} Maria Aparecida de Souza 
━━━━━━━━━━━━━━━━━━`)
console.log(`~> Consultando o nome ${texto}`)
await cliente(msg_espera)
await sleep(500)
await reagir(m.chat, m.key, "🕗")
let api_de_nome2 = await fetchJson(`https://mr-ubutu.herokuapp.com/puxar?type=nome2&q=${texto}&token=${tokenvip}`)
if (api_de_nome2.resultado != undefined) {
    consult(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗡𝗢𝗠𝗘 (2) 🕵️
═════════════════

${api_de_nome2.resultado}
  
👑 Usuário: ${pushname}

🔛 BY: ${fake}

═════════════════`)
} else {
m.reply(`⚠ NOME NÃO ENCONTRADO!`)  
}
}
}
  break  
           case 'nome3': 
               case 'name3': {
if (!isPremiumGp && !isPremium2) return noprem(`Somente usuário premium pode utilizar comandos de consultas!`)
let user3 = global.db.data.users[m.sender]
if (user3.consultas != -1) {
tempo_de_espera = clockString(new Date - user3.consultas).replace("00:00:", " ")
m.reply(`➥ Aguarde 30 segundos para consultar novamente!\n\nTempo já passado: ${tempo_de_espera} segundos ⌛`)
 } else {
if (!texto) return m.reply(`🔍 CONSULTA VIP 🔍
━━━━━━━━━━━━━━━━━━
╭──────────────
┇   𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗡𝗢𝗠𝗘:  
╰──────────────

Você precisa digitar o comando e em seguida, digite o nome completo da vítima que deseja procurar.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} Maria Aparecida de Souza 
━━━━━━━━━━━━━━━━━━`)
console.log(`~> Consultando o nome ${texto}`)
await cliente(msg_espera)
await sleep(500)
await reagir(m.chat, m.key, "🕗")
let api_de_nome3 = await fetchJson(`https://mr-ubutu.herokuapp.com/puxar?type=nome3&q=${texto}&token=${tokenvip}`)
if (api_de_nome3.resultado != undefined) {
    consult(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗡𝗢𝗠𝗘 (3) 🕵️
═════════════════

${api_de_nome3.resultado}
  
👑 Usuário: ${pushname}

🔛 BY: ${fake}

═════════════════`)
} else {
m.reply(`⚠ NOME NÃO ENCONTRADO!`)  
}
}
}
  break  

        case 'placa': {
if (!isPremiumGp && !isPremium2) return noprem(`Somente usuário premium pode utilizar comandos de consultas!`)
let user3 = global.db.data.users[m.sender]
if (user3.consultas != -1) {
tempo_de_espera = clockString(new Date - user3.consultas).replace("00:00:", " ")
m.reply(`➥ Aguarde 30 segundos para consultar novamente!\n\nTempo já passado: ${tempo_de_espera} segundos ⌛`)
 } else {             
var query = texto
if(query.length < 7 || query.length > 11) return m.reply(`🔍 CONSULTA VIP 🔍
━━━━━━━━━━━━━━━━━━
╭──────────────
┇   𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗣𝗟𝗔𝗖𝗔:  
╰──────────────

Você precisa digitar o comando e em seguida, digite a placa do veículo que deseja consultar.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} JYE9708
━━━━━━━━━━━━━━━━━━`)
await cliente(msg_espera)
await sleep(500)
await reagir(m.chat, m.key, "🕗")
console.log(`~> Consultando a placa ${texto}`)
apixx = await fetchJson(`https://mr-ubutu.herokuapp.com/puxar?type=placa&q=${texto}&token=${tokenvip}`)
if (apixx.resultado != undefined) {

str2 = apixx.resultado.replace(
`𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗣𝗟𝗔𝗖𝗔`,
`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗣𝗟𝗔𝗖𝗔 🕵️
═════════════════`
);


consult(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗣𝗟𝗔𝗖𝗔 🕵️
═════════════════

${apixx.resultado}
  
👑 Usuário: ${pushname}

🔛 BY: ${fake}

═════════════════`)

} else {
m.reply(`⚠️ PLACA NÃO ENCONTRADA!`)  
}
}
}
break
        case 'placa2': {
if (!isPremiumGp && !isPremium2) return noprem(`Somente usuário premium pode utilizar comandos de consultas!`)
let user3 = global.db.data.users[m.sender]
if (user3.consultas != -1) {
tempo_de_espera = clockString(new Date - user3.consultas).replace("00:00:", " ")
m.reply(`➥ Aguarde 30 segundos para consultar novamente!\n\nTempo já passado: ${tempo_de_espera} segundos ⌛`)
 } else {             
var query = texto
if(query.length < 7 || query.length > 11) return m.reply(`🔍 CONSULTA VIP 🔍
━━━━━━━━━━━━━━━━━━
╭──────────────
┇   𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗣𝗟𝗔𝗖𝗔:  
╰──────────────

Você precisa digitar o comando e em seguida, digite a placa do veículo que deseja consultar.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} JYE9708
━━━━━━━━━━━━━━━━━━`)
await cliente(msg_espera)
await sleep(500)
await reagir(m.chat, m.key, "🕗")
console.log(`~> Consultando a placa ${texto}`)
apixx = await fetchJson(`https://mr-ubutu.herokuapp.com/puxar?type=placa2&q=${texto}&token=${tokenvip}`)
if (apixx.resultado != undefined) {

str2 = apixx.resultado.replace(
`𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗣𝗟𝗔𝗖𝗔`,
`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗣𝗟𝗔𝗖𝗔 🕵️
═════════════════`
);


consult(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗣𝗟𝗔𝗖𝗔 🕵️
═════════════════

${apixx.resultado}
  
👑 Usuário: ${pushname}

🔛 BY: ${fake}

═════════════════`)

} else {
m.reply(`⚠️ PLACA NÃO ENCONTRADA!`)  
}
}
}
break
case 'cns': {
if (!isPremiumGp && !isPremium2) return noprem(`Somente usuário premium pode utilizar comandos de consultas!`)
let user3 = global.db.data.users[m.sender]
if (user3.consultas != -1) {
tempo_de_espera = clockString(new Date - user3.consultas).replace("00:00:", " ")
m.reply(`➥ Aguarde 30 segundos para consultar novamente!\n\nTempo já passado: ${tempo_de_espera} segundos ⌛`)
await sleep(tempo_de_consulta)
 } else {
if (!texto) return m.reply(`🔍 CONSULTA VIP 🔍
━━━━━━━━━━━━━━━━━━
╭──────────────
┇   𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗖𝗡𝗦:  
╰──────────────

Você precisa digitar o comando e em seguida, digite o cns da vítima que deseja consultar.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} 703106349459960
━━━━━━━━━━━━━━━━━━`)
if (query.length < 15 || query.length > 20) return m.reply(`⚠️ FORMATO INCORRETO ⚠️
━━━━━━━━━━━━━━━━━━

O cns que você digitou não tem 15 dígitos!

✅ Formato correto:

703106349459960

• Use o comando novamente com o cns no formato correto.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} 703106349459960
━━━━━━━━━━━━━━━━━━`)
await cliente(msg_espera)
await sleep(500)
await reagir(m.chat, m.key, "🕗")
console.log(`~> Consultando Cns ${texto}`)
let api_de_cns = await fetchJson(`https://mr-ubutu.herokuapp.com/puxar?type=cns&q=${texto}&token=${tokenvip}`)
if (api_de_cns.resultado != undefined) {
   consult(`${api_de_cns.resultado}
  
👑 Usuário: ${pushname}

🔛 BY: ${fake}

═════════════════`)
} else {
m.reply(`⚠ CNS NÃO ENCONTRADO!`)  
}
}
}
  break  
 
            case 'cnpj': {
if (!isPremiumGp && !isPremium2) return noprem(`Somente usuário premium pode utilizar comandos de consultas!`)
let user3 = global.db.data.users[m.sender]
if (user3.consultas != -1) {
tempo_de_espera = clockString(new Date - user3.consultas).replace("00:00:", " ")
m.reply(`➥ Aguarde 30 segundos para consultar novamente!\n\nTempo já passado: ${tempo_de_espera} segundos ⌛`)
 } else {        
if(!texto) return m.reply(`🔍 CONSULTA VIP 🔍
━━━━━━━━━━━━━━━━━━
╭──────────────
┇   𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗖𝗡𝗣𝗝:  
╰──────────────

Você precisa digitar o comando e em seguida, digite o cnpj da empresa que deseja consultar.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} 39708509000129
━━━━━━━━━━━━━━━━━━`)
var query = texto
.split('/').join('')
.split('+').join('')
.split('-').join('')
.split(' ').join('')
.split('(').join('')
.split(')').join('');
if (query.length < 11 || query.length > 18) return m.reply(`⚠️ FORMATO INCORRETO ⚠️
━━━━━━━━━━━━━━━━━━

O cnpj que você digitou não tem 14 dígitos!

❌ Formato incorreto:

39.708.509/0001-29

✅ Formato correto:

39708509000129

• Use o comando novamente com o cnpj no formato correto.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} 39708509000129
━━━━━━━━━━━━━━━━━━`)
await cliente(msg_espera)
await sleep(500)
await reagir(m.chat, m.key, "🕗")
console.log(`~> Consultando o cnpj ${texto}`)
res = await fetchJson(`https://mr-ubutu.herokuapp.com/puxar?type=cnpj&q=${texto}&token=${tokenvip}`);
if (res.resultado != undefined) {
   consult(`${res.resultado}  

👑 Usuário: ${pushname}

🔛 BY: ${fake}

 ━━━━━━━━━━━━━━━━━━`)
} else {
    m.reply(`⚠ CNPJ NÃO ENCONTRADO`)
}
}
}
break     
            case 'cnpj2': {
if (!isPremiumGp && !isPremium2) return noprem(`Somente usuário premium pode utilizar comandos de consultas!`)
let user3 = global.db.data.users[m.sender]
if (user3.consultas != -1) {
tempo_de_espera = clockString(new Date - user3.consultas).replace("00:00:", " ")
m.reply(`➥ Aguarde 30 segundos para consultar novamente!\n\nTempo já passado: ${tempo_de_espera} segundos ⌛`)
 } else {          
if(!texto) return m.reply(`🔍 CONSULTA VIP 🔍
━━━━━━━━━━━━━━━━━━
╭──────────────
┇   𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗖𝗡𝗣𝗝:  
╰──────────────

Você precisa digitar o comando e em seguida, digite o cnpj da empresa que deseja consultar.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} 39708509000129
━━━━━━━━━━━━━━━━━━`)
var query = texto
.split('/').join('')
.split('+').join('')
.split('-').join('')
.split(' ').join('')
.split('(').join('')
.split(')').join('');
if (query.length < 11 || query.length > 18) return m.reply(`⚠️ FORMATO INCORRETO ⚠️
━━━━━━━━━━━━━━━━━━

O cnpj que você digitou não tem 14 dígitos!

❌ Formato incorreto:

39.708.509/0001-29

✅ Formato correto:

39708509000129

• Use o comando novamente com o cnpj no formato correto.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} 39708509000129
━━━━━━━━━━━━━━━━━━`)
await cliente(msg_espera)
await sleep(500)
await reagir(m.chat, m.key, "🕗")
console.log(`~> Consultando o cnpj ${texto}`)
if(query.length < 11) return m.reply(`➥ 𝙄𝙨𝙨𝙤 𝙣𝙖̃𝙤 𝙚́ 𝙪𝙢 𝙘𝙣𝙥𝙟 𝙫𝙖́𝙡𝙞𝙙𝙤!`);
res = await fetchJson(`https://www.receitaws.com.br/v1/cnpj/${query}`);
 
if (res.cnpj != undefined) {

let atvpr = `═════════════════\n🔍 CONSULTA DE CNPJ 🔍\n═════════════════\n\n✍ CNPJ: ${res.cnpj != null ? res.cnpj : "SEM INFORMAÇÕES"}\n\n📝 ATIVIDADE PRINCIPAL:\n`
for(let i of res.atividade_principal){
   atvpr += `\n- TIPO: ${i.text ? i.text : "SEM INFORMAÇÕES"}`
   atvpr += `\n- CODIGO: ${i.code ? i.code : "SEM INFORMAÇÕES"}\n`
   }
   
consulta = `\n📞 DADOS INFORMATIVOS:\n\nDATA: ${res.data_situacao != null ? res.data_situacao : "SEM INFORMAÇÕES"} 
COMPLEMENTO: ${res.complemento != null ? res.complemento : "SEM INFORMAÇÕES"} 
TIPO: ${res.tipo != null ? res.tipo : "SEM INFORMAÇÕES"} 
NOME: ${res.nome != null ? res.nome : "SEM INFORMAÇÕES"} 
UF: ${res.uf != null ? res.uf : "SEM INFORMAÇÕES"} 
TELEFONE: ${res.telefone != null ? res.telefone : "SEM INFORMAÇÕES"} 
EMAIL: ${res.email != null ? res.email : "SEM INFORMAÇÕES"}\n`

 teks = `\n👥 ATIVIDADES SECUDARIAS:\n\n`
 for(let i of res.atividades_secundarias){
   teks += `- TIPO: ${i.text ? i.text : "SEM INFORMAÇÕES"}`
   teks += `\n- CODIGO: ${i.code ? i.code : "SEM INFORMAÇÕES"}\n`
}

let qsa = `\n👑 SÓCIOS ADMINISTRATIVOS:\n\n`
for(let i of res.qsa){
  qsa += `\n- QUAL: ${i.qual ? i.qual : "SEM INFORMAÇÕES"}`
  qsa += `\n- NOME: ${i.nome ? i.nome : "SEM INFORMAÇÕES"}`
  qsa += `\n- REPRESENTANTE LEGAL: ${i.qual_rep_legal ? i.qual_rep_legal : "SEM INFORMAÇÕES"}`
  qsa += `\n- NOME REP. LEGAL: ${i.nome_rep_legal ? i.nome_rep_legal : "SEM INFORMAÇÕES"}\n`
   }
   
 consulta2k = `\n🏬 DADOS & LOCALIZAÇÃO\n\nSITUAÇÃO: ${res.situacao != null ? res.situacao : "SEM INFORMAÇÕES"}
BAIRRO: ${res.bairro != null ? res.bairro : "SEM INFORMAÇÕES"}
LOGRADOURO: ${res.logradouro != null ? res.logradouro : "SEM INFORMAÇÕES"}
NÚMERO: ${res.numero != null ? res.numero : "SEM INFORMAÇÕES"}
CEP: ${res.cep != null ? res.cep : "SEM INFORMAÇÕES"}
MUNICIPIO: ${res.municipio != null ? res.municipio : "SEM INFORMAÇÕES"}
ABERTURA: ${res.abertura != null ? res.abertura : "SEM INFORMAÇÕES"}
NATUREZA JURIDICA: ${res.natureza_juridica != null ? res.natureza_juridica : "SEM INFORMAÇÕES"}
ULTIMA ATUALIZAÇÃO: ${res.ultima_atualizacao != null ? res.ultima_atualizacao : "SEM INFORMAÇÕES"}
STATUS: ${res.status != null ? res.status : "SEM INFORMAÇÕES"}
FANTASIA: ${res.fantasia != null ? res.fantasia : "SEM INFORMAÇÕES"}
EFR: ${res.efr != null ? res.efr : "SEM INFORMAÇÕES"}
SITUAÇÃO: ${res.motivo_situacao != null ? res.motivo_situacao : "SEM INFORMAÇÕES"}
SITUAÇÃO ESPECIAL: ${res.situacao_especial != null ? res.situacao_especial : "SEM INFORMAÇÕES"}
DATA DA SITUAÇÃO ESPECIAL: ${res.data_situacao_especial != null ? res.data_situacao_especial : "SEM INFORMAÇÕES"}
CAPITAL SOCIAL: ${res.capital_social != null ? res.capital_social : "SEM INFORMAÇÕES"}

👑 Usuário: ${pushname}

🔛 BY: ${fake}

 ━━━━━━━━━━━━━━━━━━`
consult(atvpr + consulta + teks + qsa + consulta2k)
} else {
    m.reply(`⚠ CNPJ NÃO ENCONTRADO`)
}
}
}
break
case 'chkgg': {
 if (!isPremiumGp && !isPremium2) return noprem(`Somente usuário premium pode utilizar comandos de consultas!`)
let user3 = global.db.data.users[m.sender]
 if (user3.consultas != -1) {
tempo_de_espera = clockString(new Date - user3.consultas).replace("00:00:", " ")
m.reply(`➥ Aguarde 30 segundos para consultar novamente!\n\nTempo já passado: ${tempo_de_espera} segundos ⌛`)
 } else {          
if(!texto) return m.reply(`🔍 CONSULTA VIP 🔍
━━━━━━━━━━━━━━━━━━
╭──────────────
┇   𝗖𝗛𝗘𝗖𝗞𝗘𝗥 𝗚𝗚:  
╰──────────────

Testador de Cartões de Crédito ou Débito gerados, testa a validade do cartão e obtém os detalhes do emissor (como onde ele está localizado) e os detalhes do cartão (como tipo, a bandeira e a categoria).

Bandeiras Suportadas:
MASTERCARD e VISA

Formato:
4984069234151378|02|2022|377

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} 4984069234151378|02|2022|377
━━━━━━━━━━━━━━━━━━`)

 var kls = text
 var kls1 = kls.split("|")[0];
 if (!kls1) return m.reply(`⚠️ FORMATO INCORRETO ⚠️
━━━━━━━━━━━━━━━━━━

A cc que você digitou está no formato errado ou está faltando algum número ou símbolo.

❌ Formato incorreto:

4984069234151378 02 2022 377

✅ Formato correto:

4984069234151378|02|2022|377

• Use o comando novamente com a cc no formato correto.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} 4984069234151378|02|2022|377
━━━━━━━━━━━━━━━━━━`)
 var kls2 = kls.split("|")[1];
 if (!kls2) return m.reply(`⚠️ FORMATO INCORRETO ⚠️
━━━━━━━━━━━━━━━━━━

A cc que você digitou está no formato errado ou está faltando algum número ou símbolo.

❌ Formato incorreto:

4984069234151378 02 2022 377

✅ Formato correto:

4984069234151378|02|2022|377

• Use o comando novamente com a cc no formato correto.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} 4984069234151378|02|2022|377
━━━━━━━━━━━━━━━━━━`)
 var kls3 = kls.split("|")[2];
 if (!kls3) return m.reply(`⚠️ FORMATO INCORRETO ⚠️
━━━━━━━━━━━━━━━━━━

A cc que você digitou está no formato errado ou está faltando algum número ou símbolo.

❌ Formato incorreto:

4984069234151378 02 2022 377

✅ Formato correto:

4984069234151378|02|2022|377

• Use o comando novamente com a cc no formato correto.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
${prefixo+command} 4984069234151378|02|2022|377
━━━━━━━━━━━━━━━━━━`)
await cliente(msg_espera)
await sleep(500)
await reagir(m.chat, m.key, "🕗")
console.log(`~> Consultando a cc ${texto}`)
res = await fetchJson(`https://mr-ubutu.herokuapp.com/puxar?type=chk&q=${text}&token=${tokenvip}`);
if (res.resultado != undefined) {
   consult(`═════════════════
🕵️ 𝗖𝗛𝗘𝗖𝗞𝗘𝗥 𝗚𝗚 🕵️
═════════════════

${res.resultado}  

👑 Usuário: ${pushname}

🔛 BY: ${fake}

 ━━━━━━━━━━━━━━━━━━`)
} else {
    m.reply(`⚠ NADA ENCONTRADO!`)
}
}
}
break
case 'ip': {
let user3 = global.db.data.users[m.sender]
if (user3.consultas != -1) {
tempo_de_espera = clockString(new Date - user3.consultas).replace("00:00:", " ")
m.reply(`➥ Aguarde 30 segundos para consultar novamente!\n\nTempo já passado: ${tempo_de_espera} segundos ⌛`)
 } else {
    if(!texto) return m.reply('☑️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗜𝗣\n\n━━━━━━━━━━━━━━━━━━━━━\nConsulta o número de IP, obtém dados do IP, como qual é o provedor, ip reverso, país, estado, cidade e as coordenadas de onde ele está localizado.\n\nFormato:\n204.152.203.157\n\n/ip 204.152.203.157\n\n━━━━━━━━━━━━━━━━━━━━━');
    var query = texto
    .split('.').join('')
    .split('-').join('')
    .split(' ').join('');
    if(query.length < 6) return m.reply('☑️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗜𝗣\n\n━━━━━━━━━━━━━━━━━━━━━\nConsulta o número de IP, obtém dados do IP, como qual é o provedor, ip reverso, país, estado, cidade e as coordenadas de onde ele está localizado.\n\nFormato:\n204.152.203.157\n\n/ip 204.152.203.157\n\n━━━━━━━━━━━━━━━━━━━━━');
    if(isNaN(query)) return m.reply('☑️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗜𝗣\n\n━━━━━━━━━━━━━━━━━━━━━\nConsulta o número de IP, obtém dados do IP, como qual é o provedor, ip reverso, país, estado, cidade e as coordenadas de onde ele está localizado.\n\nFormato:\n204.152.203.157\n\n/ip 204.152.203.157\n\n━━━━━━━━━━━━━━━━━━━━━');
                await enviar(msg_espera)
                await sleep(500)
                await reagir(m.chat, m.key, "🕗")
                MsgAguarde(m.sender);
                hehe = await fetchJson(`http://ip-api.com/json/${texto}`)
 
        if (hehe.country != undefined) {
    consulta = `═════════════════════
🔍 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗜𝗣 🔍
═════════════════════

• 𝗣𝗮𝗶̄𝘀: ${hehe.country}
• 𝗦𝗶𝗴𝗹𝗮: ${hehe.countryCode}
• 𝗥𝗲𝗴𝗶𝗮̃𝗼: ${hehe.regionName}
• 𝗖𝗶𝗱𝗮𝗱𝗲: ${hehe.city}
• 𝗖𝗲𝗽: ${hehe.zip}
• 𝗟𝗮𝘁: ${hehe.lat}
• 𝗟𝗼𝗻: ${hehe.lon}
• 𝗙𝘂𝘀𝗼 𝗛𝗼𝗿𝗮̀𝗿𝗶𝗼: ${hehe.timezone}
• 𝗡𝗲𝘁: ${hehe.isp}

👤 Usuário: ${pushname}

🔛 BY: ${fake}

━━━━━━━━━━━━━━━━━━`
consult(consulta)
await sleep(3500)
await client.sendMessage(m.chat, { location: { degreesLatitude: hehe.lat, degreesLongitude: hehe.lon }, m})
} else {
    m.reply(`⚠️ IP NÃO ENCONTRADO`)
}
}
}
  break
case 'bin': {
let user3 = global.db.data.users[m.sender]
if (user3.consultas != -1) {
tempo_de_espera = clockString(new Date - user3.consultas).replace("00:00:", " ")
m.reply(`➥ Aguarde 30 segundos para consultar novamente!\n\nTempo já passado: ${tempo_de_espera} segundos ⌛`)
 } else {
    if(!texto) return m.reply(`☑️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗕𝗜𝗡\n\n━━━━━━━━━━━━━━━━━━━━━\nConsulta de BIN, obtém os detalhes do emissor (como qual banco ou instituição financeira emitiu o cartão e onde ele está localizado), o tipo, a bandeira e a categoria do cartão.\n\nFormato:\n498408\n\n/bin 498408\n\n━━━━━━━━━━━━━━━━━━━━━`)
    cc = args.join(' ')
    var query = texto
    .split('.').join('')
    .split('-').join('')
    .split(' ').join('');
    if(query.length < 5 || query.length > 11) return m.reply(`☑️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗕𝗜𝗡\n\n━━━━━━━━━━━━━━━━━━━━━\nConsulta de BIN, obtém os detalhes do emissor (como qual banco ou instituição financeira emitiu o cartão e onde ele está localizado), o tipo, a bandeira e a categoria do cartão.\n\nFormato:\n498408\n\n/bin 498408\n\n━━━━━━━━━━━━━━━━━━━━━`);
    if(isNaN(query)) return m.reply(`☑️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗕𝗜𝗡\n\n━━━━━━━━━━━━━━━━━━━━━\nConsulta de BIN, obtém os detalhes do emissor (como qual banco ou instituição financeira emitiu o cartão e onde ele está localizado), o tipo, a bandeira e a categoria do cartão.\n\nFormato:\n498408\n\n/bin 498408\n\n━━━━━━━━━━━━━━━━━━━━━`);
    console.log(`~> Consultando o cpf ${texto}`)
await enviar(msg_espera)
await sleep(500)
await reagir(m.chat, m.key, "🕗")
MsgAguarde(m.sender);
let api_de_cpf = await fetchJson(`https://mr-ubutu.herokuapp.com/puxar?type=bin&q=${texto}&token=${tokenvip}`)
if (api_de_cpf.resultado != undefined) {
    consult(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗕𝗜𝗡 🕵️
═════════════════

${api_de_cpf.resultado}
  
👤 Usuário: ${pushname}

🔛 BY: ${fake}

═════════════════`)
} else {
m.reply(`⚠ BIN NÃO ENCONTRADO!`)  
}
}
}
  break
case 'cep': {
let user3 = global.db.data.users[m.sender]
if (user3.consultas != -1) {
tempo_de_espera = clockString(new Date - user3.consultas).replace("00:00:", " ")
m.reply(`➥ Aguarde 30 segundos para consultar novamente!\n\nTempo já passado: ${tempo_de_espera} segundos ⌛`)
 } else {
if(!texto) return m.reply (`☑️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗖𝗘𝗣\n\n━━━━━━━━━━━━━━━━━━━━━\nConsulta de CEP, obtém informações sobre os logradouros (como nome de rua, avenida, alameda, beco, travessa, praça etc), nome de bairro, cidade e estado onde ele está localizado.\n\nFormato:\n70040010\nou\n70040-010\n\n/cep 70040010\n\n━━━━━━━━━━━━━━━━━━━━━`)
var query = texto
.split('.').join('')
.split('-').join('')
.split(' ').join('');
if(query.length < 4 || query.length > 11) return m.reply('☑️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗖𝗘𝗣\n\n━━━━━━━━━━━━━━━━━━━━━\nConsulta de CEP, obtém informações sobre os logradouros (como nome de rua, avenida, alameda, beco, travessa, praça etc), nome de bairro, cidade e estado onde ele está localizado.\n\nFormato:\n70040010\nou\n70040-010\n\n/cep 70040010\n\n━━━━━━━━━━━━━━━━━━━━━');
if(isNaN(query)) return m.reply('☑️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗖𝗘𝗣\n\n━━━━━━━━━━━━━━━━━━━━━\nConsulta de CEP, obtém informações sobre os logradouros (como nome de rua, avenida, alameda, beco, travessa, praça etc), nome de bairro, cidade e estado onde ele está localizado.\n\nFormato:\n70040010\nou\n70040-010\n\n/cep 70040010\n\n━━━━━━━━━━━━━━━━━━━━━');
await enviar(msg_espera)
await sleep(500)
await reagir(m.chat, m.key, "🕗")
MsgAguarde(m.sender);
cer = await fetchJson(`https://cep.awesomeapi.com.br/json/${texto}`)
 
if (cer.cep != undefined) {
consulta = `═════════════════
🔍 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗖𝗘𝗣 🔍
═════════════════

• Cep: ${cer.cep}
• DDD: ${cer.ddd}
• Estado: ${cer.state}
• Tipo de logradouro: ${cer.address_type}
• Nome do logradouro: ${cer.address_name}
• Rua: ${cer.address}
• Bairro: ${cer.district}
• Cidade: ${cer.city}
• Latitude: ${cer.lat} 
• Longitude: ${cer.lng} 

👤 Usuário: ${pushname}

🔛 BY: ${fake}

━━━━━━━━━━━━━━━━━━`
consult(consulta)
await sleep(3500)
await client.sendMessage(m.chat, { location: { degreesLatitude: cer.lat, degreesLongitude: cer.lng }, })
} else {
    m.reply(`⚠️ CEP NÃO ENCONTRADO`)
}
}
}
  break 

case 'idget': {
// if (!isRegistrar) return m.reply(semreg)
if (!texto) return m.reply('➥ Mande um link de grupo!')
if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) return m.reply('➥ Link inválido!')
   
let result = args[0].split('https://chat.whatsapp.com/')[1]
await client.groupAcceptInvite(result).then(res2 => {
var geitdd = res2.replace(`""`, ``);
m.reply(geitdd)
})
}
break            

                case 'comunicado': {
                    if (!isDono) return m.reply(msg.dono)      
                    if (!m.isGroup) return m.reply (msg.grupo)   
                    if (!isBotAdmins) return m.reply(msg.botAdmin) 
                    if (!texto) return m.reply(`➥ Digite a mensagem que deseja comunicar!`)
                    await comunicado(m.chat, texto)
                    m.reply(`➥ Comunicado enviando para ${participants.length} membros!`)
                    }
                    break 

case 'delete': case 'del': case 'd': case 'apagar': {
await sleep(300)
let { chat, fromMe, id, isBaileys } = m.quoted
if (!isBaileys) return m.reply('➥ Mencione uma mensagem do bot para ser deletada!')
client.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: m.quoted.id, participant: m.quoted.sender } }) 
}
break

case 'deletec': {
// if (!isRegistrar) return m.reply(semreg)
if (!m.quoted) return m.reply('➥ Mencione uma mensagem do bot para ser deletada!')
let { chat, fromMe, id, isBaileys } = m.quoted
client.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: m.quoted.id, participant: m.quoted.sender } })
await sleep(500)
m.reply(`➥ Mensagem deletada com sucesso!`)
}
break   
case 'ping':
case 'speed':
// if (!isRegistrar) return m.reply(semreg)
await client.sendMessage(m.chat, { image: { url: `https://eruakorl.sirv.com/Bot%20dudinha/ping.jpeg?text.0.text=VELOCIDADE%20DO%20BOT&text.0.position.gravity=north&text.0.position.y=15%25&text.0.size=40&text.0.font.family=Teko&text.0.font.weight=800&text.0.background.opacity=100&text.0.outline.blur=100&text.1.text=${ping.toFixed(4)}&text.1.position.gravity=center&text.1.size=30&text.1.color=ffffff&text.1.font.family=Teko&text.1.font.weight=800&text.1.background.opacity=100&text.1.outline.blur=100`  }, caption: `${ping.toFixed(4)}` }, { quoted: m })
break                    

case 'hidetag': {
// if (!isRegistrar) return m.reply(semreg)
if (!m.isGroup) return m.reply (msg.grupo)
if (!isBotAdmins) return m.reply(msg.botAdmin)
if (!isAdmins && !isDono) return m.reply(semadm)
client.sendMessage(m.chat, { text : q ? q : '' , mentions: participants.map(a => a.id)}, { quoted: m })
}
break
 
	case 'kick': case 'ban': case 'banir': {
	// if (!isRegistrar) return m.reply(semreg)
	if (!m.isGroup) return m.reply (msg.grupo)
    if (!isBotAdmins) return m.reply (msg.botAdmin)
    if (!isAdmins && !isDono) return m.reply(semadm)
    let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
    if (users === "554891089432@s.whatsapp.net") return m.reply(`Eu não posso remover meu dono`) 
    if (users === mek.key.fromMe) return m.reply(`Eu não posso remover eu mesmo`)
	await client.groupParticipantsUpdate(m.chat, [users], 'remove').then((res) => m.reply(`➥ Usuário @${users.split('@')[0]} removido com sucesso!️`)).catch((err) => m.reply(`➥ Erro ao remover o usuário @${users.split('@')[0]}`))
	}
	break
            
	case 'gpbot': case 'grupodobot': case 'gbot': {
	// if (!isRegistrar) return m.reply(semreg)	
		m.reply(`➥ Adicionando ${pushname} ao grupo oficial, caso não seja adicionado, estarei enviando um link no seu privado.`)
		
		let gbot = `994409567740-1621113533@g.us`	
		let response = await client.groupInviteCode(gbot)	
		let metadata2 = await client.groupMetadata(gbot)		
        await client.sendText(sender, `*💌「 CONVITE 」💌*\n\n• Grupo: ${metadata2.subject}\n\n• Membros: ${metadata2.participants.length}\n\n• Link: https://chat.whatsapp.com/${response}\n\n• Ass: ${fake}`, m, { detectLink: true })       	
		await sleep(1500)         
		await client.groupParticipantsUpdate(gbot, [sender], 'add').then((res) => m.reply(`➥ Usuário ${pushname} adicionado no grupo com sucesso!`).catch((err) => m.reply(`➥ Erro ao lhe adicionar no grupo!\n\n➥ Foi enviado o link do grupo no seu privado, entre no grupo manualmente!`)))	
}
	break

    case 'block': {
    // if (!isRegistrar) return m.reply(semreg)
	if (!isDono) return m.reply(msg.dono)
	let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
	await client.updateBlockStatus(users, 'block').then((res) => m.reply(`➥ Usuário @${users.split('@')[0]} bloqueado com sucesso !️`)).catch((err) => m.reply(`➥ Erro ao bloquear o usuário @${users.split('@')[0]}!`))
	}
	break
case 'desbloquear': {
// if (!isRegistrar) return m.reply(semreg)
		if (!isDono) return m.reply(msg.dono)
		let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@'
		await client.updateBlockStatus(users, 'unblock').then((res) => m.reply(`➥ Usuário desbloqueado com sucesso!`)).catch((err) => m.reply(`➥ Erro ao desbloquear o usuário!`))
	}
	break

case 'resetarlink': case 'revogar': {
if (!m.isGroup) return m.reply(msg.grupo)
if (!isBotAdmins) return m.reply(msg.botAdmin)
if (!isAdmins) return m.reply(msg.admin)
try {
await client.groupRevokeInvite(m.chat)
m.reply(`➥ Link do grupo resetado com sucesso!`)
} catch(e) {
console.log(e)
m.reply(`➥ Erro ao resetar o link do grupo!`)
}
}
break

case 'linkgp': case 'linkgc': {
// if (!isRegistrar) return m.reply(semreg)
if (!m.isGroup) return m.reply (msg.grupo)
if (!isBotAdmins) return m.reply(msg.botAdmin)
let response = await client.groupInviteCode(m.chat)
client.sendText(m.chat, `https://chat.whatsapp.com/${response}`, m, { detectLink: true })
}
break    

			case 'setbio': {
				if (!isDono && !mek.key.fromMe) return m.reply(msg.dono)
				if (args.length < 1) return m.reply(`➥ Digite a mensagem da biografia!`)
					client.setStatus(`${texto}`)
					m.reply(`➥ Sucesso ao mudar a biografia do bot!`)
					}
					break
case 'entrar': {
// if (!isRegistrar) return m.reply(semreg)
if (!isDono) return m.reply(msg.dono)
if (!texto) return m.reply(`➥ Mande um link do grupo!`)
if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) return m.reply(`➥ Link inválido`)
m.reply(msg.aguarde)
let result = args[0].split('https://chat.whatsapp.com/')[1]
await client.groupAcceptInvite(result).then((res) => m.reply(`➥ Pronto ✔️`)).catch((err) => m.reply(`➥ Erro ❌`))
}
break

case 'sair': {
// if (!isRegistrar) return m.reply(semreg)
if (!isDono) return m.reply(msg.dono)
await client.groupLeave(m.chat).then((res) => m.reply("➥ Pronto ✔️")).catch((err) => m.reply("➥ Erro ❌"))
}
break

case 'seradm': {
if (!m.isGroup) return m.reply (msg.grupo)
if (!isDono) return m.reply(msg.dono)
if (!isBotAdmins) return m.reply(msg.botAdmin)   
await client.groupParticipantsUpdate(m.chat, [sender], 'promote')
m.reply(`➥ Agora voce é adm do grupo!`)
}
break
case 'sermembro': {
if (!m.isGroup) return m.reply (msg.grupo)
if (!isDono) return m.reply(msg.dono)
if (!isBotAdmins) return m.reply(msg.botAdmin)
await client.groupParticipantsUpdate(m.chat, [sender], 'demote')
m.reply(`➥ Agora você è um membro comum!`)
}
break

   case 'copiar': {
     // if (!isRegistrar) return m.reply(semreg)
     client.sendMessage(m.sender, {text: `${texto}`})
     await sleep(50)
     m.reply(`➥ Consulta enviada em texto no seu privado!`)
     }
     break
  case 'copiartk': {
     // if (!isRegistrar) return m.reply(semreg)
     client.sendMessage(m.chat, {text: `${texto}`})
     }
     break

            //INICIO DOS COMANDOS
	    case 'afk': {
	    if (!isDono) return enviar(msg.dono)
                let user = global.db.data.users[m.sender]
                user.afkTime = + new Date
                user.afkReason = texto
                m.reply(`${m.pushName} Esta afk (offline) ${texto ? ': ' + texto : ''}`)
            }
            break	
	             

            default:
                if (budy.startsWith('=>')) {
                    if (!isDono) return m.reply(msg.dono)
                    function Return(sul) {
                        sat = JSON.stringify(sul, null, 2)
                        bang = util.format(sat)
                            if (sat == undefined) {
                                bang = util.format(sul)
                            }
                            return m.reply(bang)
                    }
                    try {
                        m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
                    } catch (e) {
                        m.reply(String(e))
                    }
                }

                if (budy.startsWith('>')) {
                    if (!isDono) return m.reply(msg.dono)
                    try {
                        let evaled = await eval(budy.slice(2))
                        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
                        await m.reply(evaled)
                    } catch (err) {
                        await m.reply(String(err))
                    }
                }

                if (budy.startsWith('$')) {
                    if (!isDono) return m.reply(msg.dono)
                    exec(budy.slice(2), (err, stdout) => {
                        if(err) return m.reply(err)
                        if (stdout) return m.reply(stdout)
                    })
                }
			
		if (m.chat.endsWith('@s.whatsapp.net') && isCmd) {
                    this.anonymous = this.anonymous ? this.anonymous : {}
                    let room = Object.values(this.anonymous).find(room => [room.a, room.b].includes(m.sender) && room.state === 'CHATTING')
                    if (room) {
                        if (/^.*(next|leave|start)/.test(m.text)) return
                        if (['.next', '.leave', '.stop', '.start', 'Cari Partner', 'Keluar', 'Lanjut', 'Stop'].includes(m.text)) return
                        let other = [room.a, room.b].find(user => user !== m.sender)
                        m.copyNForward(other, true, m.quoted && m.quoted.fromMe ? {
                            contextInfo: {
                                ...m.msg.contextInfo,
                                forwardingScore: 0,
                                isForwarded: true,
                                participant: other
                            }
                        } : {})
                    }
                    return !0
                }
			
		if (isCmd && budy.toLowerCase() != undefined) {
		    if (m.chat.endsWith('broadcast')) return
		    if (m.isBaileys) return
		    let msgs = global.db.data.database
		    if (!(budy.toLowerCase() in msgs)) return
		    client.copyNForward(m.chat, msgs[budy.toLowerCase()], true)
		}
        }
        

    } catch (err) {
        console.log(util.format(err))
    }
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})
